﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace QuanLyBanHang.Class
{
    internal class Functions
    {
        public static SqlConnection Con = new SqlConnection();  //Khai báo đối tượng kết nối        

        public static void Connect()
        {
            //Con = new SqlConnection();   //Khởi tạo đối tượng
            Con.ConnectionString = @"Data Source=THUYEN\SQLEXPRESS;Initial Catalog=QUANLY_BANHANG;Integrated Security=True;Trust Server Certificate=True";
            Con.Open();                  //Mở kết nối
                                         //Kiểm tra kết nối
            if (Con.State == ConnectionState.Open)
                MessageBox.Show("Kết nối thành công");
            else MessageBox.Show("Không thể kết nối với dữ liệu");

        }
        public static void Disconnect()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();    //Đóng kết nối
                Con.Dispose();  //Giải phóng tài nguyên
                Con = null;
            }
        }
        public static DataTable GetDataToTable(string sql)
        {
            if (Con.ConnectionString == null || Con.ConnectionString == "")
            {
                // Set the ConnectionString property if it hasn't been initialized
                Con.ConnectionString = @"Data Source=THUYEN\SQLEXPRESS;Initial Catalog=QUANLY_BANHANG;Integrated Security=True";
            }
            DataTable table = new DataTable();
            SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
            dap.Fill(table);
            return table;
        }
        public static void RunSQL(string sql)
        {
            if (Con.State != ConnectionState.Open)
            {
                // Open the connection if it is closed
                Con.Open();
            }
            SqlCommand cmd; //Đoi tuợng thuoc lop SqlComman
            cmd = new SqlCommand();
            cmd.Connection = Con; //Gán kết nối
            cmd.CommandText = sql; //Gán lệnh SQL
            try
            {
                cmd.ExecuteNonQuery(); //Thực hien cau lệnh
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                {
                    cmd.Dispose();//Giải phóng bộ nhớ
                    cmd = null;
                }
            }
        }
        public static bool CheckKey(string sql)
        {
            SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
            DataTable table = new DataTable();
            dap.Fill(table);
            if (table.Rows.Count > 0)
                return true;
            else return false;
        }
    }
}
