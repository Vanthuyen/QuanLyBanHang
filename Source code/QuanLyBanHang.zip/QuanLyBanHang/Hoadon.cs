﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using QuanLyBanHang.Class;

namespace btnSP
{
    public partial class Hoadon : Form
    {
        private DataTable tblCTHDB;
        public Hoadon()
        {
            InitializeComponent();
        }
        internal class Functions
        {
            public static SqlConnection Con = new SqlConnection();  //Khai báo đối tượng kết nối        
            public static string currentMSP = "";
            public static void Connect()
            {
                //Con = new SqlConnection();   //Khởi tạo đối tượng
                Functions.Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                Con.Open();                  //Mở kết nối
                                             //Kiểm tra kết nối
                if (Con.State == ConnectionState.Open)
                    MessageBox.Show("Kết nối thành công");
                else MessageBox.Show("Không thể kết nối với dữ liệu");

            }
            public static void Disconnect()
            {
                if (Con.State == ConnectionState.Open)
                {
                    Con.Close();    //Đóng kết nối
                    Con.Dispose();  //Giải phóng tài nguyên
                    Con = null;
                }
            }
            public static DataTable GetDataToTable(string sql)
            {

                if (Functions.Con.ConnectionString == null || Functions.Con.ConnectionString == "")
                {
                    // Set the ConnectionString property if it hasn't been initialized
                    Functions.Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                }
                DataTable table = new DataTable();
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                dap.Fill(table);
                return table;
            }
            public static string ConvertDateTime(string date)
            {
                string[] elements = date.Split('/');
                string dt = string.Format("{0}/{1}/{2}", elements[0], elements[1], elements[2]);
                return dt;
            }
            public static void RunSQL(string sql)
            {
                if (Con.State != ConnectionState.Open)
                {
                    // Open the connection if it is closed
                    Con.Open();
                }
                SqlCommand cmd; //Đoi tuợng thuoc lop SqlComman
                cmd = new SqlCommand();
                cmd.Connection = Con; //Gán kết nối
                cmd.CommandText = sql; //Gán lệnh SQL
                try
                {
                    cmd.ExecuteNonQuery(); //Thực hien cau lệnh
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    {
                        cmd.Dispose();//Giải phóng bộ nhớ
                        cmd = null;
                    }
                }
            }
            public static bool CheckKey(string sql)
            {
                if (Functions.Con.ConnectionString == null || Functions.Con.ConnectionString == "")
                {
                    // Set the ConnectionString property if it hasn't been initialized
                    Functions.Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                }
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                DataTable table = new DataTable();
                dap.Fill(table);
                if (table.Rows.Count > 0)
                    return true;
                else return false;
            }
            public static void FillCombo(string sql, ComboBox cbo, string ma, string ten)
            {
                if (Functions.Con.ConnectionString == null || Functions.Con.ConnectionString == "")
                {
                    // Set the ConnectionString property if it hasn't been initialized
                    Functions.Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                }
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                DataTable table = new DataTable();
                dap.Fill(table);
                cbo.DataSource = table;
                cbo.ValueMember = ma; //Trường giá trị
                cbo.DisplayMember = ten; //Trường hiển thị
            }

            public static string[] GetCustomerInfor(string sql)
            {
                //string[] infor = ["", ""];
                string[] infor = new string[] { "", "" };

                SqlCommand cmd = new SqlCommand(sql, Con);
                SqlDataReader reader;
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    infor[0] = reader.GetValue(0).ToString();
                    infor[1] = reader.GetValue(1).ToString();
                }
                reader.Close();
                return infor;
            }

            public static string GetFieldValues(string sql)
            {
                string ma = "";
                SqlCommand cmd = new SqlCommand(sql, Con);
                SqlDataReader reader;
                reader = cmd.ExecuteReader();
                while (reader.Read())
                    ma = reader.GetValue(0).ToString();
                reader.Close();
                return ma;
            }
            public static void RunSqlDel(string sql)
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = Functions.Con;
                cmd.CommandText = sql; //Gán lệnh SQL với dấu nháy đơn

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    //MessageBox.Show("Dữ liệu đang được dùng, không thể xoá...", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    MessageBox.Show(ex.ToString());
                }
                cmd.Dispose();
                cmd = null;
            }
            public static string CreateKey(string tiento)
            {
                //string key = tiento;
                //string[] partsDay;
                //partsDay = DateTime.Now.ToShortDateString().Split('/');
                ////Ví dụ 07/08/2009
                //string d = String.Format("{0}{1}{2}", partsDay[0], partsDay[1], partsDay[2]);
                //key = key + d;
                //string[] partsTime;
                //partsTime = DateTime.Now.ToLongTimeString().Split(':');
                ////Ví dụ 7:08:03 PM hoặc 7:08:03 AM
                //if (partsTime[2].Substring(3, 2) == "PM")
                //    partsTime[0] = ConvertTimeTo24(partsTime[0]);
                //if (partsTime[2].Substring(3, 2) == "AM")
                //    if (partsTime[0].Length == 1)
                //        partsTime[0] = "0" + partsTime[0];
                ////Xóa ký tự trắng và PM hoặc AM
                //partsTime[2] = partsTime[2].Remove(2, 3);
                //string t;
                //t = String.Format("_{0}{1}{2}", partsTime[0], partsTime[1], partsTime[2]);
                //key = key + t;
                //return key;
                string key = tiento;

                // Tạo phần ngày
                string[] partsDay = DateTime.Now.ToShortDateString().Split('/');
                string d = String.Format("{0}{1}{2}", partsDay[0], partsDay[1], partsDay[2]);
                key = key + d;

                // Tạo phần giờ
                string[] partsTime = DateTime.Now.ToLongTimeString().Split(':');
                if (partsTime[2].Substring(3, 2) == "PM")
                    partsTime[0] = ConvertTimeTo24(partsTime[0]);
                if (partsTime[2].Substring(3, 2) == "AM" && partsTime[0].Length == 1)
                    partsTime[0] = "0" + partsTime[0];
                partsTime[2] = partsTime[2].Remove(2, 3);
                string t = String.Format("_{0}{1}{2}", partsTime[0], partsTime[1], partsTime[2]);
                key = key + t;

                // Tạo phần số ngẫu nhiên để đảm bảo độ dài là 6 ký tự
                Random random = new Random();
                int randomNumber = random.Next(1000, 9999); // Số ngẫu nhiên từ 100000 đến 999999
                key = key + randomNumber.ToString();

                // Giới hạn độ dài của key là 6 ký tự
                if (key.Length > 6)
                    key = key.Substring(0, 6);

                return key;
            }
            public static string ConvertTimeTo24(string hour)
            {
                string h = "";
                switch (hour)
                {
                    case "1":
                        h = "13";
                        break;
                    case "2":
                        h = "14";
                        break;
                    case "3":
                        h = "15";
                        break;
                    case "4":
                        h = "16";
                        break;
                    case "5":
                        h = "17";
                        break;
                    case "6":
                        h = "18";
                        break;
                    case "7":
                        h = "19";
                        break;
                    case "8":
                        h = "20";
                        break;
                    case "9":
                        h = "21";
                        break;
                    case "10":
                        h = "22";
                        break;
                    case "11":
                        h = "23";
                        break;
                    case "12":
                        h = "0";
                        break;
                }
                return h;
            }

        }
        private void LoadDataGridView()
        {
            //if (MaHD.Text != "")
            //{
            string sql;
            sql = "SELECT a.MaSP, b.TenSP, a.SLBan, b.GiaBan,a.ThanhTien FROM BAN_CHITIET AS a join SANPHAM AS b on a.MaSP=b.MaSP WHERE  MaHD = N'" + MaHD.Text + "'";
            tblCTHDB = Functions.GetDataToTable(sql);
            dataGridViewHD.DataSource = tblCTHDB;
            dataGridViewHD.Columns[0].HeaderText = "Mã Sản phẩm";
            dataGridViewHD.Columns[1].HeaderText = "Tên hàng";
            dataGridViewHD.Columns[2].HeaderText = "Số lượng";
            dataGridViewHD.Columns[3].HeaderText = "Đơn giá";
            dataGridViewHD.Columns[4].HeaderText = "Thành tiền";
            dataGridViewHD.Columns[0].Width = 80;
            dataGridViewHD.Columns[1].Width = 200;
            dataGridViewHD.Columns[2].Width = 80;
            dataGridViewHD.Columns[3].Width = 90;
            dataGridViewHD.Columns[4].Width = 90;
            dataGridViewHD.AllowUserToAddRows = false;
            dataGridViewHD.EditMode = DataGridViewEditMode.EditProgrammatically;
            MaHD.Enabled = true;
            //}



        }
        private void Hoadon_Load(object sender, EventArgs e)
        {

            if (Functions.Con.ConnectionString == null || Functions.Con.ConnectionString == "")
            {
                // Set the ConnectionString property if it hasn't been initialized
                Functions.Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
            }
            if (Functions.Con.State == ConnectionState.Closed)
            {
                Functions.Con.Open();
            }

            LoadDataGridView();
            Them.Enabled = true;
            Lưu.Enabled = false;
            Xoa.Enabled = false;
            MaHD.ReadOnly = false;
            TenNV.ReadOnly = true;
            //TenKH.ReadOnly = false;
            //DCKH.ReadOnly = false;
            //SDTKH.ReadOnly = false;
            GiaBan.ReadOnly = true;
            Thanhtien.ReadOnly = true;
            TongTien.ReadOnly = true;
            TongTien.Text = "0";
            Functions.FillCombo("SELECT MaKH, TenKH, DiachiKH , SdtKH FROM KHACHHANG", MaKH, "MaKH", "TenKH");
            //MaKH.SelectedIndex = -1;
            Functions.FillCombo("SELECT MaNV, TenNV FROM NHANVIEN", MaNV, "MaNV", "TenNV");
            //MaNV.SelectedIndex = -1;
            Functions.FillCombo("SELECT MaSP, TenSP FROM SANPHAM", cboMaSP, "MaSP", "TenSP");
            //cboMaSP.SelectedIndex = -1;
            //Hiển thị thông tin của một hóa đơn được gọi từ form tìm kiếm
            if (MaHD.Text != "")
            {
                LoadInfoHoaDon();
                Xoa.Enabled = true;
            }
            ResetValues();
        }
        private void ResetValues()
        {
            MaHD.Text = "";
            NgayBan.Text = DateTime.Now.ToShortDateString();
            TenNV.Text = "";
            TenKH.Text = "";
            MaNV.Text = "";
            MaKH.Text = "";
            TongTien.Text = "0";
            cboMaSP.Text = "";
            SL.Text = "";
            Thanhtien.Text = "0";
            DCKH.Text = "";
            SDTKH.Text = "";
            TenSP.Text = "";
            GiaBan.Text = "0";
        }
        private void ResetValuesHang()
        {
            cboMaSP.Text = "";
            SL.Text = "";
            Thanhtien.Text = "0";
        }
        private void LoadInfoHoaDon()
        {
            string str;
            str = "SELECT NgayBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'";
            NgayBan.Text = Functions.ConvertDateTime(Functions.GetFieldValues(str));
            str = "SELECT MaNV FROM BAN WHERE MaHD = N'" + MaHD.Text + "'";
            MaNV.SelectedValue = Functions.GetFieldValues(str);
            str = "SELECT MaKH FROM BAN WHERE MaHD = N'" + MaHD.Text + "'";
            MaKH.SelectedValue = Functions.GetFieldValues(str);
            str = "SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'";
            TongTien.Text = Functions.GetFieldValues(str);
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Them_Click(object sender, EventArgs e)
        {
            //Xoa.Enabled = false;
            //Lưu.Enabled = true;
            //Them.Enabled = true;
            //ResetValues();
            ////MaHD.Text = Functions.CreateKey("HD");
            //MaHD.Enabled = true;
            //MaKH.Enabled = true;
            //TenKH.ReadOnly = true;
            //DCKH.ReadOnly = true;
            //SDTKH.ReadOnly = true;
            //LoadDataGridView();
            // Reset data on DataGridView
            tblCTHDB.Rows.Clear();
            // Enable input fields
            MaHD.Enabled = true;
            MaHD.ReadOnly = false;
            MaKH.Enabled = true;
            MaNV.Enabled = true;
            TenKH.ReadOnly = true;
            DCKH.ReadOnly = true;
            SDTKH.ReadOnly = true;
            dataGridViewHD.DataSource = tblCTHDB;

            // Reset values


            // Enable buttons
            Them.Enabled = true;
            Lưu.Enabled = true;
            Xoa.Enabled = false;




            MaHD.Focus();
            ResetValues();
        }

        private void MaKH_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            string CustomerId = Convert.ToString(cmb.SelectedValue);
            if (cmb.SelectedIndex != 0)
            {
                TenKH.Text = CustomerId;
                //Get data cussotmer from DB, get Diachi & SDT by CustomerId
                string sql = "SELECT DiaChiKH, SdtKH FROM KHACHHANG WHERE MaKH=N'" + CustomerId + "'";
                string[] infor = Functions.GetCustomerInfor(sql);
                DCKH.Text = infor[0];
                SDTKH.Text = infor[1];
            }
        }

        private void Lưu_Click(object sender, EventArgs e)
        {
            string sql;
            double sl, SLcon, tong, Tongmoi;
            sql = "SELECT MaHD FROM BAN WHERE MaHD=N'" + MaHD.Text + "'";
            if (!Functions.CheckKey(sql))
            {
                // Mã hóa đơn chưa có, tiến hành lưu các thông tin chung
                // Mã HDBan được sinh tự động do đó không có trường hợp trùng khóa
                if (NgayBan.Text.Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập ngày bán", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    NgayBan.Focus();
                    return;
                }
                if (MaNV.Text.Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MaNV.Focus();
                    return;
                }
                if (MaKH.Text.Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MaKH.Focus();
                    return;
                }
                //sql = "INSERT INTO BAN(MaHD,MaKH, MaNV,NgayBan ,TongTienBan) VALUES (N'" + MaHD.Text.Trim() + "',N'" +
                //        MaKH.SelectedValue + "',N" + MaNV.SelectedValue + "','"
                //        + Functions.ConvertDateTime(NgayBan.Text.Trim()) + "',N'" + TongTien.Text + ")";
                sql = "INSERT INTO BAN(MaHD,MaKH, MaNV,NgayBan ,TongTienBan) " +
                    "VALUES (N'" + MaHD.Text.Trim() + "',N'" +
                MaKH.SelectedValue + "',N'" + MaNV.SelectedValue + "','" +
                Functions.ConvertDateTime(NgayBan.Text.Trim()) + "',N'" + TongTien.Text + "')";
                Functions.RunSQL(sql);
            }
            // Lưu thông tin của các mặt hàng
            if (cboMaSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboMaSP.Focus();
                return;
            }
            if ((SL.Text.Trim().Length == 0) || (SL.Text == "0"))
            {
                MessageBox.Show("Bạn phải nhập số lượng hoặc số nguyên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SL.Text = "";
                SL.Focus();
                return;
            }
            sql = "SELECT MaSP FROM BAN_CHITIET WHERE " +
                "MaSP=N'" + cboMaSP.SelectedValue + "' AND MaHD = N'" + MaHD.Text.Trim() + "'";
            if (Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã hàng này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetValuesHang();
                cboMaSP.Focus();
                return;
            }
            // Kiểm tra xem số lượng hàng trong kho còn đủ để cung cấp không?
            sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + cboMaSP.SelectedValue + "'"));
            if (Convert.ToDouble(SL.Text) > sl)
            {
                MessageBox.Show("Số lượng mặt hàng này chỉ còn " + sl, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SL.Text = "";
                SL.Focus();
                return;
            }
            sql = "INSERT INTO BAN_CHITIET(MaHD,MaSP,SLBan,ThanhTien) VALUES(N'" + MaHD.Text.Trim() + "',N'" + cboMaSP.SelectedValue + "'," + SL.Text + "," + Thanhtien.Text + ")";
            Functions.RunSQL(sql);
            LoadDataGridView();
            // Cập nhật lại số lượng của mặt hàng vào bảng tblHang
            SLcon = sl - Convert.ToDouble(SL.Text);
            sql = "UPDATE SANPHAM SET SL =" + SLcon + " WHERE MaSP= N'" + cboMaSP.SelectedValue + "'";
            Functions.RunSQL(sql);
            string tongTienValue = Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'");
            tong = 0;

            if (!string.IsNullOrEmpty(tongTienValue) && double.TryParse(tongTienValue, out tong))
            {
                Tongmoi = tong + Convert.ToDouble(Thanhtien.Text);
                sql = "UPDATE BAN SET TongTienBan =" + Tongmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
                Functions.RunSQL(sql);
                TongTien.Text = Tongmoi.ToString();
                ResetValuesHang();
                Xoa.Enabled = true;
                Them.Enabled = true;
            }
            else
            {
                // Xử lý trường hợp giá trị lấy ra không phải là kiểu double hợp lệ
                MessageBox.Show("Giá trị không hợp lệ cho trường TongTienBan trong cơ sở dữ liệu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            LoadDataGridView();
            MaHD.ReadOnly = true;
            //// Cập nhật lại tổng tiền cho hóa đơn bán
            //tong = Convert.ToDouble(Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'"));
            //Tongmoi = tong + Convert.ToDouble(Thanhtien.Text);
            //sql = "UPDATE BAN SET TongTienBan =" + Tongmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
            //Functions.RunSQL(sql);
            //TongTien.Text = Tongmoi.ToString();
            //ResetValuesHang();
            //Xoa.Enabled = true;
            //Them.Enabled = true;
        }

        private void Dong_Click(object sender, EventArgs e)
        {
            Functions.Con.Close();
            this.Close();
        }

        private void MaHD_TextChanged(object sender, EventArgs e)
        {

        }

        private void TimKiem_Click(object sender, EventArgs e)
        {
            if (cboMaHD.Text == "")
            {
                MessageBox.Show("Bạn phải chọn một mã hóa đơn để tìm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboMaHD.Focus();
                return;
            }
            MaHD.Text = cboMaHD.Text;
            LoadInfoHoaDon();
            LoadDataGridView();
            Xoa.Enabled = true;
            Lưu.Enabled = true;

            cboMaHD.SelectedIndex = -1;
        }

        private void cboMaSP_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            string ProductId = Convert.ToString(cmb.SelectedValue);
            if (cmb.SelectedIndex != 0)
            {
                TenSP.Text = ProductId;
                //Get data cussotmer from DB, get Diachi & SDT by CustomerId
                string sql = "SELECT GiaBan FROM SANPHAM WHERE MaSP=N'" + ProductId + "'";
                string gia = Functions.GetFieldValues(sql);
                GiaBan.Text = gia;

                if (SL.Text != "" && int.TryParse(SL.Text, out int n))
                {
                    int sl = Convert.ToInt32(SL.Text);
                    int tien = sl * Convert.ToInt32(GiaBan.Text);
                    Thanhtien.Text = tien.ToString();
                }
            }
        }

        private void MaNV_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            string EmployeeId = Convert.ToString(cmb.SelectedValue);
            TenNV.Text = EmployeeId;
        }




        private void SL_Move(object sender, EventArgs e)
        {

        }

        private void SL_TextChanged(object sender, EventArgs e)
        {
            Thanhtien.Text = "";
            if (SL.Text != "" && int.TryParse(SL.Text, out int n))
            {
                int sl = Convert.ToInt32(SL.Text);
                int tien = sl * Convert.ToInt32(GiaBan.Text);
                Thanhtien.Text = tien.ToString();
            }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            double sl, slcon, slxoa;
            if (MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string sql = "SELECT MaSP,SLBan FROM BAN_CHITIET WHERE MaHD = N'" + MaHD.Text + "'";
                DataTable tblHang = Functions.GetDataToTable(sql);
                for (int hang = 0; hang <= tblHang.Rows.Count - 1; hang++)
                {
                    // Cập nhật lại số lượng cho các mặt hàng
                    sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + tblHang.Rows[hang][0].ToString() + "'"));
                    slxoa = Convert.ToDouble(tblHang.Rows[hang][1].ToString());
                    slcon = sl + slxoa;
                    sql = "UPDATE SANPHAM SET SL =" + slcon + " WHERE MaSP= N'" + tblHang.Rows[hang][0].ToString() + "'";
                    Functions.RunSQL(sql);
                }

                //Xóa chi tiết hóa đơn
                sql = "DELETE BAN_CHITIET WHERE MaHD=N'" + MaHD.Text + "'";
                Functions.RunSqlDel(sql);

                //Xóa hóa đơn
                sql = "DELETE BAN WHERE MaHD=N'" + MaHD.Text + "'";
                Functions.RunSqlDel(sql);
                ResetValues();
                LoadDataGridView();
                Xoa.Enabled = false;
                MaHD.Enabled = true;
            }
        }

        private void cboMaHD_DropDown(object sender, EventArgs e)
        {
            Functions.FillCombo("SELECT MaHD FROM BAN", cboMaHD, "MaHD", "MaHD");
            cboMaHD.SelectedIndex = -1;
        }

        private void cboMaHD_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Sua_Click(object sender, EventArgs e)
        {
            string sql;
            double sl, SLcon, slcu, tong, Tongmoi;
            string currrentMSP = dataGridViewHD.CurrentRow.Cells["MaSP"].Value.ToString();
            //kiểm tra đã chọn sản phẩm chưa
            if (currrentMSP == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm để chỉnh sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // Case đổi mã sản phẩm
            if (!currrentMSP.Equals(cboMaSP.SelectedValue))
            {
                //Xóa hàng và cập nhật lại số lượng hàng 
                double SoLuongxoa = Convert.ToDouble(dataGridViewHD.CurrentRow.Cells["SLBan"].Value.ToString());
                double ThanhTienxoa = Convert.ToDouble(dataGridViewHD.CurrentRow.Cells["ThanhTien"].Value.ToString());
                sql = "DELETE BAN_CHITIET WHERE MaHD=N'" + MaHD.Text + "' AND MaSP = N'" + currrentMSP + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại số lượng cho các mặt hàng
                sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + currrentMSP + "'"));
                double slcon = sl + SoLuongxoa;
                sql = "UPDATE SANPHAM SET SL =" + slcon + " WHERE MaSP= N'" + currrentMSP + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại tổng tiền cho hóa đơn bán
                tong = Convert.ToDouble(Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'"));
                double tongmoi = tong - ThanhTienxoa;
                sql = "UPDATE BAN SET TongTienBan =" + tongmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
                Functions.RunSQL(sql);
                TongTien.Text = tongmoi.ToString();

                // insert san phẩm thay đổi
                if ((SL.Text.Trim().Length == 0) || (SL.Text == "0"))
                {
                    MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SL.Text = "";
                    SL.Focus();
                    return;
                }
                sql = "SELECT MaSP FROM BAN_CHITIET WHERE " +
                    "MaSP=N'" + cboMaSP.SelectedValue + "' AND MaHD = N'" + MaHD.Text.Trim() + "'";
                if (Functions.CheckKey(sql))
                {
                    MessageBox.Show("Mã hàng này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ResetValuesHang();
                    cboMaSP.Focus();
                    return;
                }
                // Kiểm tra xem số lượng hàng trong kho còn đủ để cung cấp không?
                sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + cboMaSP.SelectedValue + "'"));
                if (Convert.ToDouble(SL.Text) > sl)
                {
                    MessageBox.Show("Số lượng mặt hàng này chỉ còn " + sl, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SL.Text = "";
                    SL.Focus();
                    return;
                }
                sql = "INSERT INTO BAN_CHITIET(MaHD,MaSP,SLBan,ThanhTien) VALUES(N'" + MaHD.Text.Trim() + "',N'" + cboMaSP.SelectedValue + "'," + SL.Text + "," + Thanhtien.Text + ")";
                Functions.RunSQL(sql);
                //LoadDataGridView();
                // Cập nhật lại số lượng của mặt hàng vào bảng tblHang
                SLcon = sl - Convert.ToDouble(SL.Text);
                sql = "UPDATE SANPHAM SET SL =" + SLcon + " WHERE MaSP= N'" + cboMaSP.SelectedValue + "'";
                Functions.RunSQL(sql);
                double total = tongmoi + Convert.ToDouble(Thanhtien.Text);
                sql = "UPDATE BAN SET TongTienBan =" + total + " WHERE MaHD = N'" + MaHD.Text + "'";
                Functions.RunSQL(sql);
                TongTien.Text = total.ToString();
                ResetValuesHang();
                Xoa.Enabled = true;
                MaHD.Enabled = true;
                LoadDataGridView();
            }
            else
            {

                slcu = Convert.ToDouble(Functions.GetFieldValues("SELECT SLBan FROM BAN_CHITIET WHERE MaSP = N'" + cboMaSP.SelectedValue + "'" + "AND MaHD = N'" + MaHD.Text + "'"));
                //Kiểm tra số lượng có thay đổi ko
                if (slcu != Convert.ToDouble(SL.Text))
                {
                    sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + cboMaSP.SelectedValue + "'"));
                    SLcon = sl + slcu;

                    if (Convert.ToDouble(SL.Text) > SLcon)
                    {
                        MessageBox.Show("Số lượng mặt hàng này chỉ còn " + sl, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        SL.Text = "";
                        SL.Focus();
                        return;
                    }

                    sql = "UPDATE BAN_CHITIET SET SLBan='" + SL.Text +
                        "',ThanhTien='" + Thanhtien.Text + "'WHERE MaSP= N'" + cboMaSP.SelectedValue + "'" + "AND MaHD = N'" + MaHD.Text + "'";
                    //them where ;
                    Functions.RunSQL(sql);

                    // Cập nhật lại số lượng của mặt hàng vào bảng tblHang
                    SLcon = SLcon - Convert.ToDouble(SL.Text);
                    sql = "UPDATE SANPHAM SET SL =" + SLcon + " WHERE MaSP= N'" + cboMaSP.SelectedValue + "'";
                    Functions.RunSQL(sql);
                    string tongTiencu = Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'");
                    double thanhtiencu = Convert.ToDouble(dataGridViewHD.CurrentRow.Cells["ThanhTien"].Value.ToString());
                    double tongtienmoi = Convert.ToDouble(tongTiencu) - thanhtiencu + Convert.ToDouble(Thanhtien.Text);
                    sql = "UPDATE BAN SET TongTienBan =" + tongtienmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
                    Functions.RunSQL(sql);
                    TongTien.Text = tongtienmoi.ToString();
                    ResetValuesHang();
                    Xoa.Enabled = true;
                    LoadDataGridView();
                    MaHD.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Vui lòng thay đổi số lượng sản phẩm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                MaHD.Enabled = true;
            }
            //sql = "SELECT MaHD FROM BAN WHERE MaHD=N'" + MaHD.Text + "'";


            //sql = "UPDATE BAN SET MaKH =N'" + MaKH.SelectedValue +
            //    "',MaNV='" + MaKH.SelectedValue +
            //    "',NgayBan='" + Functions.ConvertDateTime(NgayBan.Text.Trim()) +
            //    "',TongTienBan='" + TongTien.Text;
            //Functions.RunSQL(sql);

            //// Lưu thông tin của các mặt hàng
            //if (MaKH.Text.Trim().Length == 0)
            //{
            //    MessageBox.Show("Bạn phải nhập mã hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    MaKH.Focus();
            //    return;
            //}
            //if ((SL.Text.Trim().Length == 0) || (SL.Text == "0"))
            //{
            //    MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    SL.Text = "";
            //    SL.Focus();
            //    return;
            //}
            //sql = "SELECT MaSP FROM BAN_CHITIET WHERE " +
            //    "MaSP=N'" + cboMaSP.SelectedValue + "' AND MaHD = N'" + MaHD.Text.Trim() + "'";
            //if (Functions.CheckKey(sql))
            //{
            //    MessageBox.Show("Mã hàng này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    ResetValuesHang();
            //    cboMaSP.Focus();
            //    return;
            //}
            //// Kiểm tra xem số lượng hàng trong kho còn đủ để cung cấp không?
            //sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + cboMaSP.SelectedValue + "'"));
            //if (Convert.ToDouble(SL.Text) > sl)
            //{
            //    MessageBox.Show("Số lượng mặt hàng này chỉ còn " + sl, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    SL.Text = "";
            //    SL.Focus();
            //    return;
            //}
            ////sql = "INSERT INTO BAN_CHITIET(MaHD,MaSP,SLBan,ThanhTien) VALUES(N'" + MaHD.Text.Trim() + "',N'" + cboMaSP.SelectedValue + "'," +
            ////    SL.Text + "," + Thanhtien.Text + ")";
            //slcu = Convert.ToDouble(Functions.GetFieldValues("SELECT SLBan FROM BAN_CHITIET WHERE MaSP = N'" + cboMaSP.SelectedValue + "'"));
            //sql = "UPDATE BAN_CHITIET SET MaSP =N'" + cboMaSP.SelectedValue +
            //        "',SLBan='" + SL.Text +
            //        "',ThanhTien='" + Thanhtien.Text;
            //Functions.RunSQL(sql);
            //LoadDataGridView();
            //// Cập nhật lại số lượng của mặt hàng vào bảng tblHang
            //SLcon = sl - Convert.ToDouble(SL.Text);
            //sql = "UPDATE SANPHAM SET SL =" + SLcon + " WHERE MaSP= N'" + cboMaSP.SelectedValue + "'";
            //Functions.RunSQL(sql);
            //string tongTienValue = Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'");
            //tong = 0;

            //if (!string.IsNullOrEmpty(tongTienValue) && double.TryParse(tongTienValue, out tong))
            //{
            //    Tongmoi = tong + Convert.ToDouble(Thanhtien.Text);
            //    sql = "UPDATE BAN SET TongTienBan =" + Tongmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
            //    Functions.RunSQL(sql);
            //    TongTien.Text = Tongmoi.ToString();
            //    ResetValuesHang();
            //    Xoa.Enabled = true;
            //    Them.Enabled = true;
            //}
            //else
            //{
            //    // Xử lý trường hợp giá trị lấy ra không phải là kiểu double hợp lệ
            //    MessageBox.Show("Giá trị không hợp lệ cho trường TongTienBan trong cơ sở dữ liệu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //LoadDataGridView();
            //MaHD.ReadOnly = true;
            //// Cập nhật lại tổng tiền cho hóa đơn bán
            //tong = Convert.ToDouble(Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'"));
            //Tongmoi = tong + Convert.ToDouble(Thanhtien.Text);
            //sql = "UPDATE BAN SET TongTienBan =" + Tongmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
            //Functions.RunSQL(sql);
            //TongTien.Text = Tongmoi.ToString();
            //ResetValuesHang();
            //Xoa.Enabled = true;
            //Them.Enabled = true;
        }

        private void dataGridViewHD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Them.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaSP.Focus();
                return;
            }
            if (tblCTHDB.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            TenSP.Text = dataGridViewHD.CurrentRow.Cells["MaSP"].Value.ToString();
            cboMaSP.Text = dataGridViewHD.CurrentRow.Cells["TenSP"].Value.ToString();
            SL.Text = dataGridViewHD.CurrentRow.Cells["SLBan"].Value.ToString();
            GiaBan.Text = dataGridViewHD.CurrentRow.Cells["GiaBan"].Value.ToString();
            Thanhtien.Text = dataGridViewHD.CurrentRow.Cells["Thanhtien"].Value.ToString();
            Functions.currentMSP = dataGridViewHD.CurrentRow.Cells["MaSP"].Value.ToString();
            Sua.Enabled = true;
            Xoa.Enabled = true;
        }

        private void dataGridViewHD_DoubleClick(object sender, EventArgs e)
        {
            string MaHangxoa, sql;
            Double ThanhTienxoa, SoLuongxoa, sl, slcon, tong, tongmoi;
            if (tblCTHDB.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if ((MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
            {
                //Xóa hàng và cập nhật lại số lượng hàng 
                MaHangxoa = dataGridViewHD.CurrentRow.Cells["MaSP"].Value.ToString();
                SoLuongxoa = Convert.ToDouble(dataGridViewHD.CurrentRow.Cells["SLBan"].Value.ToString());
                ThanhTienxoa = Convert.ToDouble(dataGridViewHD.CurrentRow.Cells["ThanhTien"].Value.ToString());
                sql = "DELETE BAN_CHITIET WHERE MaHD=N'" + MaHD.Text + "' AND MaSP = N'" + MaHangxoa + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại số lượng cho các mặt hàng
                sl = Convert.ToDouble(Functions.GetFieldValues("SELECT SL FROM SANPHAM WHERE MaSP = N'" + MaHangxoa + "'"));
                slcon = sl + SoLuongxoa;
                sql = "UPDATE SANPHAM SET SL =" + slcon + " WHERE MaSP= N'" + MaHangxoa + "'";
                Functions.RunSQL(sql);
                // Cập nhật lại tổng tiền cho hóa đơn bán
                tong = Convert.ToDouble(Functions.GetFieldValues("SELECT TongTienBan FROM BAN WHERE MaHD = N'" + MaHD.Text + "'"));
                tongmoi = tong - ThanhTienxoa;
                sql = "UPDATE BAN SET TongTienBan =" + tongmoi + " WHERE MaHD = N'" + MaHD.Text + "'";
                Functions.RunSQL(sql);
                TongTien.Text = tongmoi.ToString();
                MaHD.Enabled = true;
                LoadDataGridView();
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
    }
}
