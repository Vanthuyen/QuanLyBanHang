﻿namespace btnSP
{
    partial class Sanpham
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label label1;
            panel1 = new Panel();
            GiaNhap = new TextBox();
            GiaBan = new TextBox();
            SLSP = new TextBox();
            TenSP = new TextBox();
            MaSP = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            dgvSANPHAM = new DataGridView();
            panel3 = new Panel();
            Boqua = new Button();
            Luu = new Button();
            Timkiem = new Button();
            Xoa = new Button();
            Sua = new Button();
            Them = new Button();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSANPHAM).BeginInit();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(361, 9);
            label1.Name = "label1";
            label1.Size = new Size(323, 33);
            label1.TabIndex = 0;
            label1.Text = "DANH MỤC SẢN PHẨM";
            // 
            // panel1
            // 
            panel1.Controls.Add(GiaNhap);
            panel1.Controls.Add(GiaBan);
            panel1.Controls.Add(SLSP);
            panel1.Controls.Add(TenSP);
            panel1.Controls.Add(MaSP);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(9, 10);
            panel1.Name = "panel1";
            panel1.Size = new Size(1018, 183);
            panel1.TabIndex = 0;
            // 
            // GiaNhap
            // 
            GiaNhap.Location = new Point(675, 140);
            GiaNhap.Name = "GiaNhap";
            GiaNhap.Size = new Size(260, 27);
            GiaNhap.TabIndex = 12;
            // 
            // GiaBan
            // 
            GiaBan.Location = new Point(675, 98);
            GiaBan.Name = "GiaBan";
            GiaBan.Size = new Size(260, 27);
            GiaBan.TabIndex = 11;
            // 
            // SLSP
            // 
            SLSP.Location = new Point(675, 52);
            SLSP.Name = "SLSP";
            SLSP.Size = new Size(260, 27);
            SLSP.TabIndex = 10;
            // 
            // TenSP
            // 
            TenSP.Location = new Point(183, 98);
            TenSP.Name = "TenSP";
            TenSP.Size = new Size(264, 27);
            TenSP.TabIndex = 8;
            // 
            // MaSP
            // 
            MaSP.Location = new Point(183, 51);
            MaSP.Name = "MaSP";
            MaSP.Size = new Size(264, 27);
            MaSP.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(569, 103);
            label7.Name = "label7";
            label7.Size = new Size(70, 18);
            label7.TabIndex = 6;
            label7.Text = "Giá bán: ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(569, 145);
            label6.Name = "label6";
            label6.Size = new Size(75, 18);
            label6.TabIndex = 5;
            label6.Text = "Giá nhập:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(569, 57);
            label5.Name = "label5";
            label5.Size = new Size(79, 18);
            label5.TabIndex = 4;
            label5.Text = "Số lượng:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(64, 103);
            label3.Name = "label3";
            label3.Size = new Size(111, 18);
            label3.TabIndex = 2;
            label3.Text = "Tên sản phẩm:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(64, 57);
            label2.Name = "label2";
            label2.Size = new Size(104, 18);
            label2.TabIndex = 1;
            label2.Text = "Mã sản phẩm:";
            // 
            // panel2
            // 
            panel2.Controls.Add(dgvSANPHAM);
            panel2.Location = new Point(9, 199);
            panel2.Name = "panel2";
            panel2.Size = new Size(1018, 282);
            panel2.TabIndex = 1;
            // 
            // dgvSANPHAM
            // 
            dgvSANPHAM.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSANPHAM.Dock = DockStyle.Fill;
            dgvSANPHAM.Location = new Point(0, 0);
            dgvSANPHAM.Name = "dgvSANPHAM";
            dgvSANPHAM.RowHeadersWidth = 51;
            dgvSANPHAM.Size = new Size(1018, 282);
            dgvSANPHAM.TabIndex = 0;
            dgvSANPHAM.CellClick += dgvSANPHAM_CellClick;
            // 
            // panel3
            // 
            panel3.Controls.Add(Boqua);
            panel3.Controls.Add(Luu);
            panel3.Controls.Add(Timkiem);
            panel3.Controls.Add(Xoa);
            panel3.Controls.Add(Sua);
            panel3.Controls.Add(Them);
            panel3.Location = new Point(9, 498);
            panel3.Name = "panel3";
            panel3.Size = new Size(1018, 53);
            panel3.TabIndex = 2;
            // 
            // Boqua
            // 
            Boqua.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Boqua.Location = new Point(702, 18);
            Boqua.Name = "Boqua";
            Boqua.Size = new Size(94, 29);
            Boqua.TabIndex = 6;
            Boqua.Text = "Bỏ Qua";
            Boqua.UseVisualStyleBackColor = true;
            Boqua.Click += Boqua_Click;
            // 
            // Luu
            // 
            Luu.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Luu.Location = new Point(537, 18);
            Luu.Name = "Luu";
            Luu.Size = new Size(94, 29);
            Luu.TabIndex = 4;
            Luu.Text = "Lưu";
            Luu.UseVisualStyleBackColor = true;
            Luu.Click += Luu_Click;
            // 
            // Timkiem
            // 
            Timkiem.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Timkiem.Location = new Point(867, 18);
            Timkiem.Name = "Timkiem";
            Timkiem.Size = new Size(94, 29);
            Timkiem.TabIndex = 3;
            Timkiem.Text = "Tìm kiếm";
            Timkiem.UseVisualStyleBackColor = true;
            Timkiem.Click += Timkiem_Click;
            // 
            // Xoa
            // 
            Xoa.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Xoa.Location = new Point(372, 18);
            Xoa.Name = "Xoa";
            Xoa.Size = new Size(94, 29);
            Xoa.TabIndex = 2;
            Xoa.Text = "Xóa";
            Xoa.UseVisualStyleBackColor = true;
            Xoa.Click += Xoa_Click;
            // 
            // Sua
            // 
            Sua.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Sua.Location = new Point(207, 18);
            Sua.Name = "Sua";
            Sua.Size = new Size(94, 29);
            Sua.TabIndex = 1;
            Sua.Text = "Sửa";
            Sua.UseVisualStyleBackColor = true;
            Sua.Click += Sua_Click;
            // 
            // Them
            // 
            Them.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Them.Location = new Point(42, 18);
            Them.Name = "Them";
            Them.Size = new Size(94, 29);
            Them.TabIndex = 0;
            Them.Text = "Thêm";
            Them.UseVisualStyleBackColor = true;
            Them.Click += Them_Click;
            // 
            // Sanpham
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1032, 562);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Sanpham";
            Text = "Sản Phẩm";
            Load += Sanpham_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvSANPHAM).EndInit();
            panel3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private TextBox GiaNhap;
        private TextBox GiaBan;
        private TextBox SLSP;
        private TextBox TenSP;
        private TextBox MaSP;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label3;
        private Label label2;
        private Button Timkiem;
        private Button Xoa;
        private Button Sua;
        private Button Them;
        private DataGridView dgvSANPHAM;
        private Button Luu;
        private Button Boqua;
    }
}
