﻿namespace btnSP
{
    partial class Dangnhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            txbUserName = new TextBox();
            label1 = new Label();
            panel2 = new Panel();
            txbPassWord = new TextBox();
            label2 = new Label();
            btdangnhap = new Button();
            btthoat = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(txbUserName);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(509, 67);
            panel1.TabIndex = 0;
            // 
            // txbUserName
            // 
            txbUserName.Location = new Point(197, 22);
            txbUserName.Name = "txbUserName";
            txbUserName.Size = new Size(290, 27);
            txbUserName.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(22, 25);
            label1.Name = "label1";
            label1.Size = new Size(169, 24);
            label1.TabIndex = 0;
            label1.Text = "Tên Đăng Nhập :";
            // 
            // panel2
            // 
            panel2.Controls.Add(txbPassWord);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(12, 85);
            panel2.Name = "panel2";
            panel2.Size = new Size(509, 67);
            panel2.TabIndex = 2;
            // 
            // txbPassWord
            // 
            txbPassWord.Location = new Point(197, 22);
            txbPassWord.Name = "txbPassWord";
            txbPassWord.Size = new Size(290, 27);
            txbPassWord.TabIndex = 1;
            txbPassWord.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(22, 25);
            label2.Name = "label2";
            label2.Size = new Size(113, 24);
            label2.TabIndex = 0;
            label2.Text = "Mật Khẩu :";
            // 
            // btdangnhap
            // 
            btdangnhap.BackColor = Color.Lime;
            btdangnhap.Location = new Point(266, 179);
            btdangnhap.Name = "btdangnhap";
            btdangnhap.Size = new Size(94, 29);
            btdangnhap.TabIndex = 3;
            btdangnhap.Text = "Đăng Nhập";
            btdangnhap.UseVisualStyleBackColor = false;
            btdangnhap.Click += btdangnhap_Click;
            // 
            // btthoat
            // 
            btthoat.BackColor = Color.Red;
            btthoat.Location = new Point(405, 179);
            btthoat.Name = "btthoat";
            btthoat.Size = new Size(94, 29);
            btthoat.TabIndex = 4;
            btthoat.Text = "Thoát";
            btthoat.UseVisualStyleBackColor = false;
            btthoat.Click += btthoat_Click;
            // 
            // Dangnhap
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(533, 230);
            Controls.Add(btthoat);
            Controls.Add(btdangnhap);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Dangnhap";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dangnhap";
            FormClosing += Dangnhap_FormClosing;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox txbUserName;
        private Label label1;
        private Panel panel2;
        private TextBox txbPassWord;
        private Label label2;
        private Button btdangnhap;
        private Button btthoat;
    }
}