﻿//using btnSP.DAO;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using btnSP;
using QuanLyBanHang;

namespace btnSP
{
    public partial class Dangnhap : Form
    {
        private static string connstr = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
        SqlConnection conn = new SqlConnection(connstr);

        DataTable? dt = null;
        private void openConnect()
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
        }
        private void closeConnect()
        {
            if (conn.State != ConnectionState.Closed)
            {
                conn.Close();
            }
        }
        private DataTable Request(string cmd)
        {
            openConnect();
            DataTable dt = new DataTable();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                //gan data vao datatale
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                dt = new DataTable();
                MessageBox.Show(ex.Message);
                throw;
            }
            finally
            {
                closeConnect();
            }
            return dt;
        }
        public Dangnhap()
        {
            InitializeComponent();
        }


        private void Dangnhap_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thật sự muốn thoát chương trình?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }


        private void btdangnhap_Click(object sender, EventArgs e)
        {
            if(txbUserName.Text == "admin" && txbPassWord.Text == "123456")
            {
                Main main = new Main();
                main.ShowDialog();
                Application.Exit();
            }
            else
            {
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không hợp lệ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btthoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

