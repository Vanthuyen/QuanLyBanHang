﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Globalization;

namespace btnSP
{

    public partial class Form2 : Form
    {
        private DataTable KHACHHANG;
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        /*private void formsanpham_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=LAPTOP-68DTPNF2\\MSSQLSERVER01;Initial Catalog=QUANLY_BANHANG;Integrated Security=True";
            con.Open();
            String sql = "select * from KHACHHANG";
            DataSet ds = new DataSet();
            SqlDataAdapter dap = new SqlDataAdapter(sql, con);
            dap.Fill(ds);
            dgvKhachHang.DataSource = ds.Tables[0];
            dgvKhachHang.Refresh();
        }*/

        internal class Functions
        {
            public static SqlConnection Con = new SqlConnection();  //Khai báo đối tượng kết nối        

            public static void Connect()
            {
                //Con = new SqlConnection();   //Khởi tạo đối tượng
                Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;Trust Server Certificate=True";
                Con.Open();                  //Mở kết nối
                                             //Kiểm tra kết nối
                if (Con.State == ConnectionState.Open)
                    MessageBox.Show("Kết nối thành công");
                else MessageBox.Show("Không thể kết nối với dữ liệu");

            }
            public static void Disconnect()
            {
                if (Con.State == ConnectionState.Open)
                {
                    Con.Close();    //Đóng kết nối
                    Con.Dispose();  //Giải phóng tài nguyên
                    Con = null;
                }
            }
            public static DataTable GetDataToTable(string sql)
            {
                if (Con.ConnectionString == null || Con.ConnectionString == "")
                {
                    // Set the ConnectionString property if it hasn't been initialized
                    Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                }
                DataTable table = new DataTable();
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                dap.Fill(table);
                return table;
            }
            public static void RunSQL(string sql)
            {
                if (Con.State != ConnectionState.Open)
                {
                    // Open the connection if it is closed
                    Con.Open();
                }
                SqlCommand cmd; //Đoi tuợng thuoc lop SqlComman
                cmd = new SqlCommand();
                cmd.Connection = Con; //Gán kết nối
                cmd.CommandText = sql; //Gán lệnh SQL
                try
                {
                    cmd.ExecuteNonQuery(); //Thực hien cau lệnh
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    {
                        cmd.Dispose();//Giải phóng bộ nhớ
                        cmd = null;
                    }
                }
            }
            public static bool CheckKey(string sql)
            {
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                DataTable table = new DataTable();
                dap.Fill(table);
                if (table.Rows.Count > 0)
                    return true;
                else return false;
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            LoadDataGridView();
        }
        public void LoadDataGridView()
        {
            string sql;
            sql = "SELECT * FROm KHACHHANG";
            KHACHHANG = Functions.GetDataToTable(sql); //lấy dữ liệu
            dgvKhachHang.DataSource = KHACHHANG;
            dgvKhachHang.Columns[0].HeaderText = "Mã khách";
            dgvKhachHang.Columns[1].HeaderText = "Tên khách";
            dgvKhachHang.Columns[2].HeaderText = "Điện thoại";
            dgvKhachHang.Columns[3].HeaderText = "Địa chỉ";
            dgvKhachHang.Columns[0].Width = 100;
            dgvKhachHang.Columns[1].Width = 150;
            dgvKhachHang.Columns[2].Width = 150;
            dgvKhachHang.Columns[3].Width = 150;
            dgvKhachHang.AllowUserToAddRows = false;
            dgvKhachHang.EditMode = DataGridViewEditMode.EditProgrammatically;
        }


        private void Them_Click(object sender, EventArgs e)
        {
            Sua.Enabled = false;
            Xoa.Enabled = false;
            Lưu.Enabled = true;
            Them.Enabled = false;
            Boqua.Enabled = true;
            ResetValues();
            MaKH.Enabled = true;
            MaKH.Focus();
        }
        private void ResetValues()
        {
            MaKH.Text = "";
            TenKH.Text = "";
            SDTKH.Text = "";
            ĐCKH.Text = "";
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            string sql;
            if (KHACHHANG.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MaKH.Text == "")
            {
                MessageBox.Show("Bạn phải chọn bản ghi cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (TenKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên khách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TenKH.Focus();
                return;
            }

            if (SDTKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SDTKH.Focus();
                return;
            }
            if (ĐCKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SDTKH.Focus();
                return;
            }
            //sql = "UPDATE KHACHHANG SET TenKH=N'" + TenKH.Text.Trim().ToString() + "',SdtKH='" + SDTKH.Text.ToString()+ "' WHERE MaKH=N'" + ĐCKH.Text + "'"+
            //    "' WHERE MaKH=N'" + MaKH.Text + "'" ;
            sql = "UPDATE KHACHHANG SET TenKH=N'" + TenKH.Text.Trim().ToString() + "', SdtKH='" + SDTKH.Text.ToString() + "', DiaChiKH=N'" + ĐCKH.Text.Trim() + "' WHERE MaKH=N'" + MaKH.Text + "'";

            Functions.RunSQL(sql);
            LoadDataGridView();
            ResetValues();
            MaKH.Enabled = false;
            Boqua.Enabled = true;
            Xoa.Enabled = false;
            Timkiem.Enabled = false;
            Them.Enabled = false;
            Lưu.Enabled = false;
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            string sql;
            if (KHACHHANG.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MaKH.Text.Trim() == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xoá bản ghi này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                sql = "DELETE KHACHHANG WHERE MaKH=N'" + MaKH.Text + "'";
                Functions.RunSQL(sql);
                LoadDataGridView();
                ResetValues();
            }
        }

        private void Lưu_Click(object sender, EventArgs e)
        {
            string sql;
            if (MaKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã khách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaKH.Focus();
                return;
            }
            if (TenKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên khách", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TenKH.Focus();
                return;
            }
            if (SDTKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SDTKH.Focus();
                return;
            }
            if (ĐCKH.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ĐCKH.Focus();
                return;
            }
            //Kiểm tra đã tồn tại mã khách chưa
            sql = "SELECT MaKH FROM KHACHHANG WHERE MaKH=N'" + MaKH.Text.Trim() + "'";
            if (Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã khách này đã tồn tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaKH.Focus();
                return;
            }
            //Chèn thêm
            sql = "INSERT INTO KHACHHANG VALUES (N'" + MaKH.Text.Trim() +
                "',N'" + TenKH.Text.Trim() + "','" + SDTKH.Text + "',N'" + ĐCKH.Text.Trim() + "')";
            Functions.RunSQL(sql);
            LoadDataGridView();
            ResetValues();

            Xoa.Enabled = true;
            Them.Enabled = true;
            Sua.Enabled = true;
            Boqua.Enabled = false;
            Lưu.Enabled = false;
            MaKH.Enabled = false;
        }

        private void Boqua_Click(object sender, EventArgs e)
        {
            ResetValues();
            Boqua.Enabled = true;
            Them.Enabled = true;
            Xoa.Enabled = true;
            Sua.Enabled = true;
            Lưu.Enabled = true;
            Timkiem.Enabled = true;
            MaKH.Enabled = true;
            TenKH.Enabled = true;
            SDTKH.Enabled = true;
            ĐCKH.Enabled = true;
        }

        private void Timkiem_Click(object sender, EventArgs e)
        {
            string searchMaKH = MaKH.Text.Trim();
            if (!string.IsNullOrEmpty(searchMaKH))
            {
                string sql = "SELECT * FROM KHACHHANG WHERE MaKH LIKE '%" + searchMaKH + "%'";
                KHACHHANG = Functions.GetDataToTable(sql);
                dgvKhachHang.DataSource = KHACHHANG;
            }
            else
            {
                // Nếu ô tìm kiếm trống, hiển thị toàn bộ dữ liệu
                LoadDataGridView();
            }
            TenKH.Enabled = false;
            SDTKH.Enabled = false;
            ĐCKH .Enabled = false;
            Boqua.Enabled = true;
        }

        private void dgvKhachHang_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Them.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaKH.Focus();
                return;
            }
            if (KHACHHANG.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            MaKH.Text = dgvKhachHang.CurrentRow.Cells["MaKH"].Value.ToString();
            TenKH.Text = dgvKhachHang.CurrentRow.Cells["TenKH"].Value.ToString();
            SDTKH.Text = dgvKhachHang.CurrentRow.Cells["SdtKH"].Value.ToString();
            ĐCKH.Text = dgvKhachHang.CurrentRow.Cells["DiaChiKH"].Value.ToString();

            Sua.Enabled = true;
            Xoa.Enabled = true;
            Boqua.Enabled = true;
            MaKH.Enabled = false;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
