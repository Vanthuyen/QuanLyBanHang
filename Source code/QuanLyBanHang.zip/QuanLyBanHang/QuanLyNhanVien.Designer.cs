﻿namespace QuanLyBanHang
{
    partial class FormNhanVien
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Timkiem = new Button();
            Đóng = new Button();
            Boqua = new Button();
            Lưu = new Button();
            Sửa = new Button();
            Xóa = new Button();
            Thêm = new Button();
            panel2 = new Panel();
            SDT = new TextBox();
            ĐCNV = new TextBox();
            TenNV = new TextBox();
            MaNV = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dataGridViewNhanVien = new DataGridView();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewNhanVien).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(Timkiem);
            panel1.Controls.Add(Đóng);
            panel1.Controls.Add(Boqua);
            panel1.Controls.Add(Lưu);
            panel1.Controls.Add(Sửa);
            panel1.Controls.Add(Xóa);
            panel1.Controls.Add(Thêm);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 587);
            panel1.Name = "panel1";
            panel1.Size = new Size(1078, 101);
            panel1.TabIndex = 0;
            // 
            // Timkiem
            // 
            Timkiem.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Timkiem.Location = new Point(592, 40);
            Timkiem.Name = "Timkiem";
            Timkiem.Size = new Size(94, 29);
            Timkiem.TabIndex = 6;
            Timkiem.Text = "Tìm kiếm";
            Timkiem.UseVisualStyleBackColor = true;
            Timkiem.Click += Timkiem_Click;
            // 
            // Đóng
            // 
            Đóng.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Đóng.Location = new Point(906, 40);
            Đóng.Name = "Đóng";
            Đóng.Size = new Size(94, 25);
            Đóng.TabIndex = 5;
            Đóng.Text = "Đóng";
            Đóng.UseVisualStyleBackColor = true;
            Đóng.Click += Dong_Click;
            // 
            // Boqua
            // 
            Boqua.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Boqua.Location = new Point(750, 40);
            Boqua.Name = "Boqua";
            Boqua.Size = new Size(94, 25);
            Boqua.TabIndex = 4;
            Boqua.Text = "Bỏ Qua";
            Boqua.UseVisualStyleBackColor = true;
            Boqua.Click += Boqua_Click;
            // 
            // Lưu
            // 
            Lưu.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Lưu.Location = new Point(451, 40);
            Lưu.Name = "Lưu";
            Lưu.Size = new Size(94, 29);
            Lưu.TabIndex = 3;
            Lưu.Text = "Lưu";
            Lưu.UseVisualStyleBackColor = true;
            Lưu.Click += Lưu_Click;
            // 
            // Sửa
            // 
            Sửa.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Sửa.Location = new Point(308, 40);
            Sửa.Name = "Sửa";
            Sửa.Size = new Size(94, 29);
            Sửa.TabIndex = 2;
            Sửa.Text = "Sửa";
            Sửa.UseVisualStyleBackColor = true;
            Sửa.Click += Sửa_Click;
            // 
            // Xóa
            // 
            Xóa.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Xóa.Location = new Point(165, 40);
            Xóa.Name = "Xóa";
            Xóa.Size = new Size(94, 29);
            Xóa.TabIndex = 1;
            Xóa.Text = "Xóa";
            Xóa.UseVisualStyleBackColor = true;
            Xóa.Click += Xóa_Click;
            // 
            // Thêm
            // 
            Thêm.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Thêm.Location = new Point(22, 40);
            Thêm.Name = "Thêm";
            Thêm.Size = new Size(94, 29);
            Thêm.TabIndex = 0;
            Thêm.Text = "Thêm";
            Thêm.UseVisualStyleBackColor = true;
            Thêm.Click += Thêm_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(SDT);
            panel2.Controls.Add(ĐCNV);
            panel2.Controls.Add(TenNV);
            panel2.Controls.Add(MaNV);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1078, 245);
            panel2.TabIndex = 1;
            // 
            // SDT
            // 
            SDT.Location = new Point(726, 127);
            SDT.Name = "SDT";
            SDT.Size = new Size(250, 27);
            SDT.TabIndex = 8;
            SDT.TextChanged += SDT_TextChanged;
            // 
            // ĐCNV
            // 
            ĐCNV.Location = new Point(726, 69);
            ĐCNV.Name = "ĐCNV";
            ĐCNV.Size = new Size(252, 27);
            ĐCNV.TabIndex = 7;
            // 
            // TenNV
            // 
            TenNV.Location = new Point(201, 129);
            TenNV.Name = "TenNV";
            TenNV.Size = new Size(271, 27);
            TenNV.TabIndex = 6;
            TenNV.TextChanged += textBox2_TextChanged;
            // 
            // MaNV
            // 
            MaNV.Location = new Point(201, 67);
            MaNV.Name = "MaNV";
            MaNV.Size = new Size(271, 27);
            MaNV.TabIndex = 5;
            MaNV.TextChanged += MaNV_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label5.Location = new Point(603, 132);
            label5.Name = "label5";
            label5.Size = new Size(85, 18);
            label5.TabIndex = 4;
            label5.Text = "Điện Thoại";
            //label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label4.Location = new Point(603, 70);
            label4.Name = "label4";
            label4.Size = new Size(83, 18);
            label4.TabIndex = 3;
            label4.Text = "Địa Chỉ NV";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label3.Location = new Point(78, 132);
            label3.Name = "label3";
            label3.Size = new Size(112, 18);
            label3.TabIndex = 2;
            label3.Text = "Tên Nhân Viên";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label2.Location = new Point(78, 71);
            label2.Name = "label2";
            label2.Size = new Size(105, 18);
            label2.TabIndex = 1;
            label2.Text = "Mã Nhân Viên";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(390, 9);
            label1.Name = "label1";
            label1.Size = new Size(329, 33);
            label1.TabIndex = 0;
            label1.Text = "DANH MỤC NHÂN VIÊN";
            label1.Click += label1_Click;
            // 
            // dataGridViewNhanVien
            // 
            dataGridViewNhanVien.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewNhanVien.Dock = DockStyle.Fill;
            dataGridViewNhanVien.Location = new Point(0, 245);
            dataGridViewNhanVien.Name = "dataGridViewNhanVien";
            dataGridViewNhanVien.RowHeadersWidth = 51;
            dataGridViewNhanVien.Size = new Size(1078, 342);
            dataGridViewNhanVien.TabIndex = 2;
            dataGridViewNhanVien.CellClick += dataGridViewNhanVien_CellClick;
            // 
            // FormNhanVien
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(1078, 688);
            Controls.Add(dataGridViewNhanVien);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FormNhanVien";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Danh mục Nhân Viên";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewNhanVien).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox SDT;
        private TextBox ĐCNV;
        private TextBox TenNV;
        private TextBox MaNV;
        private Button Lưu;
        private Button Sửa;
        private Button Xóa;
        private Button Thêm;
        private DataGridView dataGridViewNhanVien;
        private Button Đóng;
        private Button Boqua;
        private Button Timkiem;
    }
}
