﻿namespace btnSP
{
    partial class Hoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            cboMaHD = new ComboBox();
            TimKiem = new Button();
            Mahoadon = new Label();
            splitContainer1 = new SplitContainer();
            ThongTinChung = new GroupBox();
            MaKH = new ComboBox();
            SDTKH = new TextBox();
            DCKH = new TextBox();
            TenKH = new TextBox();
            TenNV = new TextBox();
            MaNV = new ComboBox();
            NgayBan = new DateTimePicker();
            MaHD = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            Sua = new Button();
            cboMaSP = new ComboBox();
            TongTien = new TextBox();
            label16 = new Label();
            Dong = new Button();
            Xoa = new Button();
            Lưu = new Button();
            Them = new Button();
            panel1 = new Panel();
            dataGridViewHD = new DataGridView();
            Thanhtien = new TextBox();
            GiaBan = new TextBox();
            TenSP = new TextBox();
            SL = new TextBox();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            MaSP = new Label();
            label10 = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ThongTinChung.SuspendLayout();
            groupBox1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewHD).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Controls.Add(cboMaHD);
            panel2.Controls.Add(TimKiem);
            panel2.Controls.Add(Mahoadon);
            panel2.Location = new Point(1, 680);
            panel2.Name = "panel2";
            panel2.Size = new Size(1112, 44);
            panel2.TabIndex = 1;
            // 
            // cboMaHD
            // 
            cboMaHD.FormattingEnabled = true;
            cboMaHD.Location = new Point(113, 10);
            cboMaHD.Name = "cboMaHD";
            cboMaHD.Size = new Size(288, 28);
            cboMaHD.TabIndex = 3;
            cboMaHD.DropDown += cboMaHD_DropDown;
            cboMaHD.SelectedIndexChanged += cboMaHD_SelectedIndexChanged;
            // 
            // TimKiem
            // 
            TimKiem.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TimKiem.Location = new Point(418, 9);
            TimKiem.Name = "TimKiem";
            TimKiem.Size = new Size(94, 29);
            TimKiem.TabIndex = 2;
            TimKiem.Text = "Tìm kiếm";
            TimKiem.UseVisualStyleBackColor = true;
            TimKiem.Click += TimKiem_Click;
            // 
            // Mahoadon
            // 
            Mahoadon.AutoSize = true;
            Mahoadon.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Mahoadon.Location = new Point(11, 16);
            Mahoadon.Name = "Mahoadon";
            Mahoadon.Size = new Size(96, 18);
            Mahoadon.TabIndex = 0;
            Mahoadon.Text = "Mã hóa đơn:";
            // 
            // splitContainer1
            // 
            splitContainer1.Location = new Point(1, 2);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(ThongTinChung);
            splitContainer1.Panel1.Controls.Add(label1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(groupBox1);
            splitContainer1.Size = new Size(1112, 672);
            splitContainer1.SplitterDistance = 245;
            splitContainer1.TabIndex = 2;
            // 
            // ThongTinChung
            // 
            ThongTinChung.Controls.Add(MaKH);
            ThongTinChung.Controls.Add(SDTKH);
            ThongTinChung.Controls.Add(DCKH);
            ThongTinChung.Controls.Add(TenKH);
            ThongTinChung.Controls.Add(TenNV);
            ThongTinChung.Controls.Add(MaNV);
            ThongTinChung.Controls.Add(NgayBan);
            ThongTinChung.Controls.Add(MaHD);
            ThongTinChung.Controls.Add(label9);
            ThongTinChung.Controls.Add(label8);
            ThongTinChung.Controls.Add(label7);
            ThongTinChung.Controls.Add(label6);
            ThongTinChung.Controls.Add(label5);
            ThongTinChung.Controls.Add(label4);
            ThongTinChung.Controls.Add(label3);
            ThongTinChung.Controls.Add(label2);
            ThongTinChung.Location = new Point(11, 43);
            ThongTinChung.Name = "ThongTinChung";
            ThongTinChung.Size = new Size(1092, 190);
            ThongTinChung.TabIndex = 1;
            ThongTinChung.TabStop = false;
            ThongTinChung.Text = "Thông tin chung";
            // 
            // MaKH
            // 
            MaKH.FormattingEnabled = true;
            MaKH.Location = new Point(662, 37);
            MaKH.Name = "MaKH";
            MaKH.Size = new Size(251, 28);
            MaKH.TabIndex = 16;
            MaKH.SelectedIndexChanged += MaKH_SelectedIndexChanged;
            // 
            // SDTKH
            // 
            SDTKH.Location = new Point(658, 146);
            SDTKH.Name = "SDTKH";
            SDTKH.Size = new Size(255, 27);
            SDTKH.TabIndex = 15;
            // 
            // DCKH
            // 
            DCKH.Location = new Point(658, 112);
            DCKH.Name = "DCKH";
            DCKH.Size = new Size(255, 27);
            DCKH.TabIndex = 14;
            // 
            // TenKH
            // 
            TenKH.Location = new Point(658, 77);
            TenKH.Name = "TenKH";
            TenKH.Size = new Size(255, 27);
            TenKH.TabIndex = 13;
            // 
            // TenNV
            // 
            TenNV.Location = new Point(145, 143);
            TenNV.Name = "TenNV";
            TenNV.Size = new Size(246, 27);
            TenNV.TabIndex = 11;
            // 
            // MaNV
            // 
            MaNV.FormattingEnabled = true;
            MaNV.Location = new Point(145, 109);
            MaNV.Name = "MaNV";
            MaNV.Size = new Size(246, 28);
            MaNV.TabIndex = 10;
            MaNV.SelectedIndexChanged += MaNV_SelectedIndexChanged;
            // 
            // NgayBan
            // 
            NgayBan.Font = new Font("Courier New", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            NgayBan.Format = DateTimePickerFormat.Short;
            NgayBan.ImeMode = ImeMode.NoControl;
            NgayBan.Location = new Point(145, 76);
            NgayBan.Name = "NgayBan";
            NgayBan.Size = new Size(246, 24);
            NgayBan.TabIndex = 9;
            // 
            // MaHD
            // 
            MaHD.Location = new Point(145, 42);
            MaHD.Name = "MaHD";
            MaHD.Size = new Size(246, 27);
            MaHD.TabIndex = 8;
            MaHD.TextChanged += MaHD_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 9F, FontStyle.Bold);
            label9.Location = new Point(517, 149);
            label9.Name = "label9";
            label9.Size = new Size(85, 18);
            label9.TabIndex = 7;
            label9.Text = "Điện Thoại";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 9F, FontStyle.Bold);
            label8.Location = new Point(517, 112);
            label8.Name = "label8";
            label8.Size = new Size(59, 18);
            label8.TabIndex = 6;
            label8.Text = "Địa Chỉ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 9F, FontStyle.Bold);
            label7.Location = new Point(517, 76);
            label7.Name = "label7";
            label7.Size = new Size(119, 18);
            label7.TabIndex = 5;
            label7.Text = "Mã Khách Hàng";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 9F, FontStyle.Bold);
            label6.Location = new Point(517, 40);
            label6.Name = "label6";
            label6.Size = new Size(126, 18);
            label6.TabIndex = 4;
            label6.Text = "Tên Khách Hàng";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial", 9F, FontStyle.Bold);
            label5.Location = new Point(37, 149);
            label5.Name = "label5";
            label5.Size = new Size(105, 18);
            label5.TabIndex = 3;
            label5.Text = "Mã Nhân Viên";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 9F, FontStyle.Bold);
            label4.Location = new Point(37, 112);
            label4.Name = "label4";
            label4.Size = new Size(112, 18);
            label4.TabIndex = 2;
            label4.Text = "Tên Nhân Viên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 9F, FontStyle.Bold);
            label3.Location = new Point(37, 76);
            label3.Name = "label3";
            label3.Size = new Size(75, 18);
            label3.TabIndex = 1;
            label3.Text = "Ngày Bán";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold);
            label2.Location = new Point(37, 40);
            label2.Name = "label2";
            label2.Size = new Size(96, 18);
            label2.TabIndex = 0;
            label2.Text = "Mã Hóa Đơn";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(398, 7);
            label1.Name = "label1";
            label1.Size = new Size(304, 33);
            label1.TabIndex = 0;
            label1.Text = "HÓA ĐƠN BÁN HÀNG";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(Sua);
            groupBox1.Controls.Add(cboMaSP);
            groupBox1.Controls.Add(TongTien);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(Dong);
            groupBox1.Controls.Add(Xoa);
            groupBox1.Controls.Add(Lưu);
            groupBox1.Controls.Add(Them);
            groupBox1.Controls.Add(panel1);
            groupBox1.Controls.Add(Thanhtien);
            groupBox1.Controls.Add(GiaBan);
            groupBox1.Controls.Add(TenSP);
            groupBox1.Controls.Add(SL);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(MaSP);
            groupBox1.Controls.Add(label10);
            groupBox1.Location = new Point(11, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1092, 408);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin các mặt hàng";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // Sua
            // 
            Sua.Font = new Font("Arial", 9F, FontStyle.Bold);
            Sua.Location = new Point(439, 373);
            Sua.Name = "Sua";
            Sua.Size = new Size(94, 29);
            Sua.TabIndex = 21;
            Sua.Text = "Sửa";
            Sua.UseVisualStyleBackColor = true;
            Sua.Click += Sua_Click;
            // 
            // cboMaSP
            // 
            cboMaSP.FormattingEnabled = true;
            cboMaSP.Location = new Point(111, 35);
            cboMaSP.Name = "cboMaSP";
            cboMaSP.Size = new Size(211, 28);
            cboMaSP.TabIndex = 20;
            cboMaSP.SelectedIndexChanged += cboMaSP_SelectedIndexChanged;
            // 
            // TongTien
            // 
            TongTien.Location = new Point(866, 338);
            TongTien.Name = "TongTien";
            TongTien.Size = new Size(183, 27);
            TongTien.TabIndex = 19;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(781, 338);
            label16.Name = "label16";
            label16.Size = new Size(84, 18);
            label16.TabIndex = 18;
            label16.Text = "Tổng tiền :";
            // 
            // Dong
            // 
            Dong.Font = new Font("Arial", 9F, FontStyle.Bold);
            Dong.Location = new Point(721, 373);
            Dong.Name = "Dong";
            Dong.Size = new Size(94, 29);
            Dong.TabIndex = 17;
            Dong.Text = "Đóng";
            Dong.UseVisualStyleBackColor = true;
            Dong.Click += Dong_Click;
            // 
            // Xoa
            // 
            Xoa.Font = new Font("Arial", 9F, FontStyle.Bold);
            Xoa.Location = new Point(580, 373);
            Xoa.Name = "Xoa";
            Xoa.Size = new Size(94, 29);
            Xoa.TabIndex = 15;
            Xoa.Text = "Hủy";
            Xoa.UseVisualStyleBackColor = true;
            Xoa.Click += Xoa_Click;
            // 
            // Lưu
            // 
            Lưu.Font = new Font("Arial", 9F, FontStyle.Bold);
            Lưu.Location = new Point(298, 373);
            Lưu.Name = "Lưu";
            Lưu.Size = new Size(94, 29);
            Lưu.TabIndex = 14;
            Lưu.Text = "Lưu";
            Lưu.UseVisualStyleBackColor = true;
            Lưu.Click += Lưu_Click;
            // 
            // Them
            // 
            Them.Font = new Font("Arial", 9F, FontStyle.Bold);
            Them.Location = new Point(157, 373);
            Them.Name = "Them";
            Them.Size = new Size(94, 29);
            Them.TabIndex = 13;
            Them.Text = "Thêm";
            Them.UseVisualStyleBackColor = true;
            Them.Click += Them_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(dataGridViewHD);
            panel1.Location = new Point(21, 114);
            panel1.Name = "panel1";
            panel1.Size = new Size(1053, 221);
            panel1.TabIndex = 12;
            // 
            // dataGridViewHD
            // 
            dataGridViewHD.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewHD.Dock = DockStyle.Fill;
            dataGridViewHD.Location = new Point(0, 0);
            dataGridViewHD.Name = "dataGridViewHD";
            dataGridViewHD.RowHeadersWidth = 51;
            dataGridViewHD.Size = new Size(1053, 221);
            dataGridViewHD.TabIndex = 0;
            dataGridViewHD.CellClick += dataGridViewHD_CellClick;
            dataGridViewHD.DoubleClick += dataGridViewHD_DoubleClick;
            // 
            // Thanhtien
            // 
            Thanhtien.Location = new Point(842, 72);
            Thanhtien.Name = "Thanhtien";
            Thanhtien.Size = new Size(232, 27);
            Thanhtien.TabIndex = 11;
            // 
            // GiaBan
            // 
            GiaBan.Location = new Point(478, 76);
            GiaBan.Name = "GiaBan";
            GiaBan.Size = new Size(232, 27);
            GiaBan.TabIndex = 10;
            // 
            // TenSP
            // 
            TenSP.Location = new Point(494, 26);
            TenSP.Name = "TenSP";
            TenSP.Size = new Size(232, 27);
            TenSP.TabIndex = 8;
            TenSP.TextChanged += textBox9_TextChanged;
            // 
            // SL
            // 
            SL.Location = new Point(111, 72);
            SL.Name = "SL";
            SL.Size = new Size(211, 27);
            SL.TabIndex = 7;
            SL.TextChanged += SL_TextChanged;
            SL.Move += SL_Move;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 9F, FontStyle.Bold);
            label15.Location = new Point(387, 81);
            label15.Name = "label15";
            label15.Size = new Size(62, 18);
            label15.TabIndex = 5;
            label15.Text = "Giá bán";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 9F, FontStyle.Bold);
            label14.Location = new Point(755, 79);
            label14.Name = "label14";
            label14.Size = new Size(89, 18);
            label14.TabIndex = 4;
            label14.Text = "Thành Tiền";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 9F, FontStyle.Bold);
            label13.Location = new Point(374, 35);
            label13.Name = "label13";
            label13.Size = new Size(103, 18);
            label13.TabIndex = 3;
            label13.Text = "Mã Sản Phẩm";
            label13.Click += label13_Click;
            // 
            // MaSP
            // 
            MaSP.AutoSize = true;
            MaSP.Font = new Font("Arial", 9F, FontStyle.Bold);
            MaSP.Location = new Point(21, 35);
            MaSP.Name = "MaSP";
            MaSP.Size = new Size(77, 18);
            MaSP.TabIndex = 1;
            MaSP.Text = "Tên Hàng";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 9F, FontStyle.Bold);
            label10.Location = new Point(21, 75);
            label10.Name = "label10";
            label10.Size = new Size(80, 18);
            label10.TabIndex = 0;
            label10.Text = "Số Lượng";
            // 
            // Hoadon
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1116, 726);
            Controls.Add(splitContainer1);
            Controls.Add(panel2);
            Name = "Hoadon";
            Text = "Hoadon";
            Load += Hoadon_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ThongTinChung.ResumeLayout(false);
            ThongTinChung.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewHD).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private Label Mahoadon;
        private Button TimKiem;
        private SplitContainer splitContainer1;
        private GroupBox ThongTinChung;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox1;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private TextBox TenNV;
        private ComboBox MaNV;
        private DateTimePicker NgayBan;
        private TextBox MaHD;
        private TextBox SDTKH;
        private TextBox DCKH;
        private TextBox TenKH;
        private Label label14;
        private Label label13;
        private Label MaSP;
        private Label label10;
        private TextBox Thanhtien;
        private TextBox TenSP;
        private TextBox SL;
        private Panel panel1;
        private TextBox TongTien;
        private Label label16;
        private Button Dong;
        private Button Xoa;
        private Button Lưu;
        private Button Them;
        private TextBox GiaBan;
        private Label label15;
        private ComboBox MaKH;
        private ComboBox cboMaSP;
        private ComboBox cboMaHD;
        private Button Sua;
        private DataGridView dataGridViewHD;
    }
}