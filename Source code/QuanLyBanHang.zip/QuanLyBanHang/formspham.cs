﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Globalization;



namespace btnSP
{
    public partial class Sanpham : Form
    {
        private DataTable SANPHAM = new DataTable();
        public Sanpham()
        {
            InitializeComponent();
        }
        internal class Functions
        {
            public static SqlConnection Con = new SqlConnection();  //Khai báo đối tượng kết nối        

            /*public static void Connect()
            {
                //Con = new SqlConnection();   //Khởi tạo đối tượng
                conn.ConnectionString = @"Data Source=LAPTOP-68DTPNF2\MSSQLSERVER01;Initial Catalog=QUANLY_BANHANG;Integrated Security=True;Trust Server Certificate=True";
                conn.Open();                  //Mở kết nối
                                              //Kiểm tra kết nối
                if (conn.State == ConnectionState.Open)
                    MessageBox.Show("Kết nối thành công");
                else MessageBox.Show("Không thể kết nối với dữ liệu")


            }*/
            public static void Connect()
            {
                if (Con == null)
                {
                    MessageBox.Show("Connection object is null");
                    return;
                }

                Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;Trust Server Certificate=True";

                if (Con.State == ConnectionState.Open)
                    MessageBox.Show("Kết nối thành công");
                else MessageBox.Show("Không thể kết nối với dữ liệu");
            }

            public static void Disconnect()
            {
                if (Con != null && Con.State == ConnectionState.Open)
                {
                    Con.Close();    //Đóng kết nối
                    Con.Dispose();  //Giải phóng tài nguyên
                    Con = null;
                }
            }
            public static DataTable GetDataToTable(string sql)
            {
                if (Con != null && (Con.ConnectionString == null || Con.ConnectionString == ""))
                {
                    // Set the ConnectionString property if it hasn't been initialized
                    Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                }
                DataTable table = new DataTable();
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                dap.Fill(table);
                return table;
            }
            public static void RunSQL(string sql)
            {
                if (Con.State != ConnectionState.Open)
                {
                    // Open the connection if it is closed
                    Con.Open();
                }
                SqlCommand cmd; //Đoi tuợng thuoc lop SqlComman
                cmd = new SqlCommand();
                cmd.Connection = Con; //Gán kết nối
                cmd.CommandText = sql; //Gán lệnh SQL
                try
                {
                    cmd.ExecuteNonQuery(); //Thực hien cau lệnh
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());

                    if (cmd != null)
                    {
                        cmd?.Dispose(); // Giải phóng bộ nhớ
                    }
                    cmd = null;
                }
            }
            public static bool CheckKey(string sql)
            {
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                DataTable table = new DataTable();
                dap.Fill(table);
                if (table.Rows.Count > 0)
                    return true;
                else return false;
            }
        }

        private void Sanpham_Load(object sender, EventArgs e)
        {
            LoadDataGridView();
        }
        public void LoadDataGridView()
        {
            string sql;
            sql = "SELECT * from SANPHAM";
            SANPHAM = Functions.GetDataToTable(sql); //lấy dữ liệu
            dgvSANPHAM.DataSource = SANPHAM;
            dgvSANPHAM.Columns[0].HeaderText = "Mã sản phẩm";
            dgvSANPHAM.Columns[1].HeaderText = "Tên sản phẩm";
            dgvSANPHAM.Columns[2].HeaderText = "Số lượng";
            dgvSANPHAM.Columns[3].HeaderText = "Giá bán";
            dgvSANPHAM.Columns[4].HeaderText = "Giá nhập";
            dgvSANPHAM.Columns[0].Width = 100;
            dgvSANPHAM.Columns[1].Width = 150;
            dgvSANPHAM.Columns[2].Width = 80;
            dgvSANPHAM.Columns[3].Width = 80;
            dgvSANPHAM.Columns[4].Width = 100;
            dgvSANPHAM.AllowUserToAddRows = false;
            dgvSANPHAM.EditMode = DataGridViewEditMode.EditProgrammatically;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            {
                Sua.Enabled = false;
                Xoa.Enabled = false;
                Luu.Enabled = true;
                Them.Enabled = false;
                ResetValues();
                MaSP.Enabled = true;
                MaSP.Focus();
                SLSP.Enabled = true;
                GiaBan.Enabled = true;
                GiaNhap.Enabled = true;
                Boqua.Enabled = true;
            }

        }
        private void ResetValues()
        {
            MaSP.Text = "";
            TenSP.Text = "";
            SLSP.Text = "";
            //DVT.Text = "";
            GiaBan.Text = "";
            GiaNhap.Text = "";
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            string sql;
            if (SANPHAM.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MaSP == null || MaSP.Text == null)
            {
                MessageBox.Show("Bạn phải chọn bản ghi cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (TenSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên sản phẩm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TenSP.Focus();
                return;
            }

            if (SLSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SLSP.Focus();
                return;
            }
            /*
            sql = "UPDATE KHACHHANG SET TenSP=N'" + TenSP.Text.Trim().ToString() + "',SLSP='" + SLSP.Text.ToString() +
                "' WHERE MaSP=N'" + MaSP.Text + "'";
            */
            if (MaSP != null && MaSP.Text != null)
            {
                sql = "UPDATE SANPHAM SET TenSP=N'" + TenSP.Text.Trim().ToString() + "',SL='" + SLSP.Text.ToString() +
                    "' WHERE MaSP=N'" + MaSP.Text + "'";
                Functions.RunSQL(sql);
                LoadDataGridView();
                ResetValues();
            }
            else
            {
                MessageBox.Show("MaSP is null or MaSP.Text is null");
            }
            MaSP.Enabled = false;
            /*Functions.RunSQL(sql);
            LoadDataGridView();
            ResetValues();*/
            //btnBoQua.Enabled = false;
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            string sql;
            if (SANPHAM.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MaSP.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xoá bản ghi này không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                sql = "DELETE SANPHAM WHERE MaSP=N'" + MaSP.Text + "'";
                Functions.RunSQL(sql);
                LoadDataGridView();
                ResetValues();
            }

        }

        private void Timkiem_Click(object sender, EventArgs e)
        {
            //string sql;
            //if ((MaSP.Text == "") && (TenSP.Text == ""))
            //{
            //    MessageBox.Show("Bạn hãy nhập điều kiện tìm kiếm", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            //}
            //sql = "SELECT * from SANPHAM WHERE 1=1";
            //if (MaSP.Text != "")
            //    sql += " AND MaSP LIKE N'%" + MaSP.Text + "%'";
            //if (TenSP.Text != "")
            //    sql += " AND TenSP LIKE N'%" + TenSP.Text + "%'";
            //SANPHAM = Functions.GetDataToTable(sql);
            //if (SANPHAM.Rows.Count == 0)
            //    MessageBox.Show("Không có bản ghi thoả mãn điều kiện tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //else MessageBox.Show("Có " + SANPHAM.Rows.Count + "  bản ghi thoả mãn điều kiện!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //dgvSANPHAM.DataSource = SANPHAM;
            //ResetValues();
            string searchMaSP = MaSP.Text.Trim();
            if (!string.IsNullOrEmpty(searchMaSP))
            {
                string sql = "SELECT * FROM SANPHAM WHERE MaSP LIKE '%" + searchMaSP + "%'";
                SANPHAM = Functions.GetDataToTable(sql);
                dgvSANPHAM.DataSource = SANPHAM;
            }
            else
            {
                // Nếu ô tìm kiếm trống, hiển thị toàn bộ dữ liệu
                LoadDataGridView();
            }
            MaSP.Enabled = true;
            Timkiem.Enabled = true;
            TenSP.Enabled = false;
            SLSP.Enabled = false;
            GiaBan.Enabled = false;
            GiaNhap.Enabled = false;
            Boqua.Enabled = true;
        }

        private void Luu_Click(object sender, EventArgs e)
        {
            string sql;
            if (MaSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaSP.Focus();
                return;
            }
            if (TenSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TenSP.Focus();
                return;
            }
            if (SLSP.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập chất liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                SLSP.Focus();
                return;
            }
            /* if (DVT.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải chọn ảnh minh hoạ cho hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DVT.Focus();
                return;
            }*/
            if (GiaBan.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải chọn ảnh minh hoạ cho hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GiaBan.Focus();
                return;
            }
            if (GiaNhap.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải chọn ảnh minh hoạ cho hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GiaNhap.Focus();
                return;
            }
            sql = "SELECT MaSP FROM SANPHAM WHERE MaSP=N'" + MaSP.Text.Trim() + "'";
            if (Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã hàng này đã tồn tại, bạn phải chọn mã hàng khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaSP.Focus();
                return;
            }
            sql = "INSERT INTO SANPHAM(MaSP,TenSP,SL,GiaBan,GiaNhap) VALUES(N'"
                + MaSP.Text.Trim() + "',N'" + TenSP.Text.Trim() +
                "',N'" + SLSP.Text +
                //"',N'" + DVT.Text.Trim() +
                "'," + GiaBan.Text +
                "," + GiaNhap.Text + ")";

            Functions.RunSQL(sql);
            LoadDataGridView();
            //ResetValues();
            Xoa.Enabled = true;
            Them.Enabled = true;
            Sua.Enabled = true;
            Boqua.Enabled = false;
            Luu.Enabled = false;
            MaSP.Enabled = false;
        }

        private void Boqua_Click(object sender, EventArgs e)
        {
            ResetValues();
            Xoa.Enabled = true;
            Sua.Enabled = true;
            Them.Enabled = true;
            Boqua.Enabled = false;
            Luu.Enabled = true;
            MaSP.Enabled = true;
            TenSP.Enabled = true;
            SLSP.Enabled = true;
            GiaBan.Enabled = true;
            GiaNhap.Enabled = true;
        }

        private void dgvSANPHAM_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Them.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaSP.Focus();
                return;
            }
            if (SANPHAM.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            MaSP.Text = dgvSANPHAM.CurrentRow.Cells["MaSP"].Value.ToString();
            TenSP.Text = dgvSANPHAM.CurrentRow.Cells["TenSP"].Value.ToString();
            SLSP.Text = dgvSANPHAM.CurrentRow.Cells["SL"].Value.ToString();
            //DVT.Text = dgvSANPHAM.CurrentRow.Cells["DVT"].Value.ToString();
            GiaBan.Text = dgvSANPHAM.CurrentRow.Cells["GiaBan"].Value.ToString();
            GiaNhap.Text = dgvSANPHAM.CurrentRow.Cells["GiaNhap"].Value.ToString();
            Sua.Enabled = true;
            Xoa.Enabled = true;
            Boqua.Enabled = true;
            MaSP.Enabled = false;
        }
    }
}
