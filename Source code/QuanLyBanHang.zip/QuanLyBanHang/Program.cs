using btnSP;

namespace QuanLyBanHang
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            Dangnhap fLogin = new Dangnhap();
            if (fLogin.ShowDialog() == DialogResult.OK)
            {
                Application.Run(new Main());
            }
            else
            {
                Application.Exit();
            }
            //Application.Run(new Hoadon());
            //Application.Run(new Main());
            //Application.Run(new Dangnhap());
            //Application.Run(new Form2());
            //Application.Run(new FormNhanVien());
        }
    }
}