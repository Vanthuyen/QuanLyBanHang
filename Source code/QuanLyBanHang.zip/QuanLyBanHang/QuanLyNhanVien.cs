﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace QuanLyBanHang
{

    public partial class FormNhanVien : Form
    {
        private DataTable tbeNV;
        public FormNhanVien()
        {
            InitializeComponent();
        }
        internal class Functions
        {
            public static SqlConnection Con = new SqlConnection();  //Khai báo đối tượng kết nối        

            public static void Connect()
            {
                //Con = new SqlConnection();   //Khởi tạo đối tượng
                Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;Trust Server Certificate=True";
                Con.Open();                  //Mở kết nối
                                             //Kiểm tra kết nối
                if (Con.State == ConnectionState.Open)
                    MessageBox.Show("Kết nối thành công");
                else MessageBox.Show("Không thể kết nối với dữ liệu");

            }
            public static void Disconnect()
            {
                if (Con.State == ConnectionState.Open)
                {
                    Con.Close();    //Đóng kết nối
                    Con.Dispose();  //Giải phóng tài nguyên
                    Con = null;
                }
            }
            public static DataTable GetDataToTable(string sql)
            {
                if (Con.ConnectionString == null || Con.ConnectionString == "")
                {
                    // Set the ConnectionString property if it hasn't been initialized
                    Con.ConnectionString = @"Data Source=Thuyen\SQLEXPRESS;Initial Catalog=QUANLYBANHANG;Integrated Security=True;";
                }
                DataTable table = new DataTable();
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                dap.Fill(table);
                return table;
            }
            public static void RunSQL(string sql)
            {
                if (Con.State != ConnectionState.Open)
                {
                    // Open the connection if it is closed
                    Con.Open();
                }
                SqlCommand cmd; //Đoi tuợng thuoc lop SqlComman
                cmd = new SqlCommand();
                cmd.Connection = Con; //Gán kết nối
                cmd.CommandText = sql; //Gán lệnh SQL
                try
                {
                    cmd.ExecuteNonQuery(); //Thực hien cau lệnh
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    {
                        cmd.Dispose();//Giải phóng bộ nhớ
                        cmd = null;
                    }
                }
            }
            public static bool CheckKey(string sql)
            {
                SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
                DataTable table = new DataTable();
                dap.Fill(table);
                if (table.Rows.Count > 0)
                    return true;
                else return false;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadDataGridView();
            Lưu.Enabled = false;
            Boqua.Enabled = false;

        }
        public void LoadDataGridView()
        {
            string sql;
            sql = "SELECT * FROm NHANVIEN";
            tbeNV = Functions.GetDataToTable(sql); //lấy dữ liệu
            dataGridViewNhanVien.DataSource = tbeNV;
            dataGridViewNhanVien.Columns[0].HeaderText = "Mã nhân viên";
            dataGridViewNhanVien.Columns[1].HeaderText = "Tên nhân viên";
            dataGridViewNhanVien.Columns[2].HeaderText = "Địa chỉ";
            dataGridViewNhanVien.Columns[3].HeaderText = "Điện thoại";
            dataGridViewNhanVien.Columns[0].Width = 200;
            dataGridViewNhanVien.Columns[1].Width = 200;
            dataGridViewNhanVien.Columns[2].Width = 500;
            dataGridViewNhanVien.Columns[3].Width = 100;
            dataGridViewNhanVien.AllowUserToAddRows = false;
            dataGridViewNhanVien.EditMode = DataGridViewEditMode.EditProgrammatically;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Lưu_Click(object sender, EventArgs e)
        {
            string sql;
            if (MaNV.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập mã nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                MaNV.Focus();
                return;
            }
            if (TenNV.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                TenNV.Focus();
                return;
            }
            if (ĐCNV.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ĐCNV.Focus();
                return;
            }
            if (SDT.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SDT.Focus();
                return;
            }
            sql = "SELECT MaNV FROM NHANVIEN WHERE MaNV=N'" + MaNV.Text.Trim() + "'";
            if (Functions.CheckKey(sql))
            {
                MessageBox.Show("Mã nhân viên này đã có, bạn phải nhập mã khác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                MaNV.Focus();
                MaNV.Text = "";
                return;
            }
            sql = "INSERT INTO NHANVIEN(MaNV,TenNV,DiaChiNV,SdtNV) VALUES (N'" + MaNV.Text.Trim() + "',N'" + TenNV.Text.Trim() + "',N'" + ĐCNV.Text.Trim() + "','" + SDT.Text.Trim() + "')";
            Functions.RunSQL(sql);
            LoadDataGridView();
            ResetValues();
            Xóa.Enabled = true;
            Thêm.Enabled = true;
            Sửa.Enabled = true;
            Boqua.Enabled = false;
            Lưu.Enabled = false;
            MaNV.Enabled = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void SDT_TextChanged(object sender, EventArgs e)
        {

        }

        /* private void dataGridViewNhanVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Thêm.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaNV.Focus();
                return;
            }
            if (tbeNV.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            MaNV.Text = dataGridViewNhanVien.CurrentRow.Cells["MaNhanVien"].Value.ToString();
            TenNV.Text = dataGridViewNhanVien.CurrentRow.Cells["TenNhanVien"].Value.ToString();
            ĐCNV.Text = dataGridViewNhanVien.CurrentRow.Cells["DiaChi"].Value.ToString();
            SDT.Text = dataGridViewNhanVien.CurrentRow.Cells["DienThoai"].Value.ToString();

            Sửa.Enabled = true;
            Xóa.Enabled = true;
            Xóa.Enabled = true;
        } */

        private void Dong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Boqua_Click(object sender, EventArgs e)
        {
            ResetValues();
            Boqua.Enabled = false;
            Thêm.Enabled = true;
            Xóa.Enabled = true;
            Sửa.Enabled = true;
            Timkiem.Enabled = true;
            Lưu.Enabled = false;
            MaNV.Enabled = true;
            TenNV.Enabled = true;
            ĐCNV.Enabled = true;
            SDT.Enabled = true;
        }

        private void Thêm_Click(object sender, EventArgs e)
        {

            Sửa.Enabled = false;
            Xóa.Enabled = false;
            Boqua.Enabled = true;
            Lưu.Enabled = true;
            Thêm.Enabled = false;
            ResetValues();
            MaNV.Enabled = true;
            MaNV.Focus();
            Boqua.Enabled = true;
        }
        private void ResetValues()
        {
            MaNV.Text = "";
            TenNV.Text = "";
            ĐCNV.Text = "";
            SDT.Text = "";
        }


        private void dataGridViewNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Thêm.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MaNV.Focus();
                return;
            }
            if (tbeNV.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            MaNV.Text = dataGridViewNhanVien.CurrentRow.Cells["MaNV"].Value.ToString();
            TenNV.Text = dataGridViewNhanVien.CurrentRow.Cells["TenNV"].Value.ToString();
            ĐCNV.Text = dataGridViewNhanVien.CurrentRow.Cells["DiaChiNV"].Value.ToString();
            SDT.Text = dataGridViewNhanVien.CurrentRow.Cells["SdtNV"].Value.ToString();

            Sửa.Enabled = true;
            Xóa.Enabled = true;
            Xóa.Enabled = true;
            MaNV.Enabled = false;
        }

        private void Sửa_Click(object sender, EventArgs e)
        {
            string sql;
            if (tbeNV.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MaNV.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (TenNV.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                TenNV.Focus();
                return;
            }
            if (ĐCNV.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ĐCNV.Focus();
                return;
            }
            if (SDT.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SDT.Focus();
                return;
            }
            sql = "UPDATE NHANVIEN SET  TenNV =N'" + TenNV.Text.Trim().ToString() +
                    "',DiaChiNV=N'" + ĐCNV.Text.Trim().ToString() +
                    "',SdtNV='" + SDT.Text.ToString() +
                    "' WHERE MaNV=N'" + MaNV.Text + "'";
            Functions.RunSQL(sql);
            LoadDataGridView();
            ResetValues();
            Boqua.Enabled = false;
        }

        private void Xóa_Click(object sender, EventArgs e)
        {
            string sql;
            if (tbeNV.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MaNV.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                sql = "DELETE NHANVIEN WHERE MaNV=N'" + MaNV.Text + "'";
                Functions.RunSQL(sql);
                LoadDataGridView();
                ResetValues();
            }
        }

        private void MaNV_TextChanged(object sender, EventArgs e)
        {


        }

        private void Timkiem_Click(object sender, EventArgs e)
        {
            string searchMaKH = MaNV.Text.Trim();
            if (!string.IsNullOrEmpty(searchMaKH))
            {
                string sql = "SELECT * FROM NHANVIEN WHERE MaNV LIKE '%" + searchMaKH + "%'";
                tbeNV = Functions.GetDataToTable(sql);
                dataGridViewNhanVien.DataSource = tbeNV;
            }
            else
            {
                // Nếu ô tìm kiếm trống, hiển thị toàn bộ dữ liệu
                LoadDataGridView();
            }
            MaNV.Enabled = true;
            Timkiem.Enabled = true;
            TenNV.Enabled = false;
            ĐCNV.Enabled = false;
            SDT.Enabled = false;
            Boqua.Enabled = true;
        }
    }

}
