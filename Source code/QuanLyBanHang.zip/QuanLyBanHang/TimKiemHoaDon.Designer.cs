﻿namespace QuanLyBanHang
{
    partial class TimKiemHoaDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Đóng = new Button();
            Timlai = new Button();
            Timkiem = new Button();
            panel2 = new Panel();
            label1 = new Label();
            panel3 = new Panel();
            dmTimkiemhoadon = new Label();
            Ttb = new TextBox();
            Tongtienban = new Label();
            Tgb = new TextBox();
            Thoigianban = new Label();
            Nb = new TextBox();
            Mkh = new TextBox();
            Mnv = new TextBox();
            Mhd = new TextBox();
            Ngayban = new Label();
            MaKH = new Label();
            MaNhanVien = new Label();
            MaHD = new Label();
            dataGridViewTKHD = new DataGridView();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTKHD).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(Đóng);
            panel1.Controls.Add(Timlai);
            panel1.Controls.Add(Timkiem);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 595);
            panel1.Name = "panel1";
            panel1.Size = new Size(1437, 71);
            panel1.TabIndex = 1;
            // 
            // Đóng
            // 
            Đóng.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Đóng.Location = new Point(674, 26);
            Đóng.Name = "Đóng";
            Đóng.Size = new Size(94, 25);
            Đóng.TabIndex = 4;
            Đóng.Text = "Đóng";
            Đóng.UseVisualStyleBackColor = true;
            Đóng.Click += Đóng_Click;
            // 
            // Timlai
            // 
            Timlai.Font = new Font("Microsoft Sans Serif", 7.8F, FontStyle.Bold);
            Timlai.Location = new Point(487, 22);
            Timlai.Name = "Timlai";
            Timlai.Size = new Size(94, 29);
            Timlai.TabIndex = 3;
            Timlai.Text = "Tìm lại";
            Timlai.UseVisualStyleBackColor = true;
            Timlai.Click += Timlai_Click;
            // 
            // Timkiem
            // 
            Timkiem.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Timkiem.Location = new Point(300, 22);
            Timkiem.Name = "Timkiem";
            Timkiem.Size = new Size(94, 29);
            Timkiem.TabIndex = 0;
            Timkiem.Text = "Tìm kiếm";
            Timkiem.UseVisualStyleBackColor = true;
            Timkiem.Click += Timkiem_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 564);
            panel2.Name = "panel2";
            panel2.Size = new Size(1437, 31);
            panel2.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.ForeColor = Color.IndianRed;
            label1.Location = new Point(16, 9);
            label1.Name = "label1";
            label1.Size = new Size(272, 18);
            label1.TabIndex = 0;
            label1.Text = "Nháy đúp để hiển thị thông tin chi tiết";
            // 
            // panel3
            // 
            panel3.Controls.Add(dmTimkiemhoadon);
            panel3.Controls.Add(Ttb);
            panel3.Controls.Add(Tongtienban);
            panel3.Controls.Add(Tgb);
            panel3.Controls.Add(Thoigianban);
            panel3.Controls.Add(Nb);
            panel3.Controls.Add(Mkh);
            panel3.Controls.Add(Mnv);
            panel3.Controls.Add(Mhd);
            panel3.Controls.Add(Ngayban);
            panel3.Controls.Add(MaKH);
            panel3.Controls.Add(MaNhanVien);
            panel3.Controls.Add(MaHD);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(1437, 256);
            panel3.TabIndex = 3;
            // 
            // dmTimkiemhoadon
            // 
            dmTimkiemhoadon.AutoSize = true;
            dmTimkiemhoadon.Font = new Font("Arial", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dmTimkiemhoadon.ForeColor = SystemColors.HotTrack;
            dmTimkiemhoadon.Location = new Point(331, 24);
            dmTimkiemhoadon.Name = "dmTimkiemhoadon";
            dmTimkiemhoadon.Size = new Size(446, 33);
            dmTimkiemhoadon.TabIndex = 21;
            dmTimkiemhoadon.Text = "DANH MỤC TÌM KIẾM HÓA ĐƠN";
            // 
            // Ttb
            // 
            Ttb.Location = new Point(697, 208);
            Ttb.Name = "Ttb";
            Ttb.Size = new Size(252, 27);
            Ttb.TabIndex = 20;
            // 
            // Tongtienban
            // 
            Tongtienban.AutoSize = true;
            Tongtienban.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Tongtienban.Location = new Point(574, 209);
            Tongtienban.Name = "Tongtienban";
            Tongtienban.Size = new Size(106, 18);
            Tongtienban.TabIndex = 19;
            Tongtienban.Text = "Tổng tiền bán";
            // 
            // Tgb
            // 
            Tgb.Location = new Point(697, 163);
            Tgb.Name = "Tgb";
            Tgb.Size = new Size(252, 27);
            Tgb.TabIndex = 18;
            // 
            // Thoigianban
            // 
            Thoigianban.AutoSize = true;
            Thoigianban.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Thoigianban.Location = new Point(574, 164);
            Thoigianban.Name = "Thoigianban";
            Thoigianban.Size = new Size(106, 18);
            Thoigianban.TabIndex = 17;
            Thoigianban.Text = "Thời gian bán";
            // 
            // Nb
            // 
            Nb.Location = new Point(208, 159);
            Nb.Name = "Nb";
            Nb.Size = new Size(271, 27);
            Nb.TabIndex = 16;
            // 
            // Mkh
            // 
            Mkh.Location = new Point(697, 118);
            Mkh.Name = "Mkh";
            Mkh.Size = new Size(252, 27);
            Mkh.TabIndex = 15;
            // 
            // Mnv
            // 
            Mnv.Location = new Point(208, 205);
            Mnv.Name = "Mnv";
            Mnv.Size = new Size(271, 27);
            Mnv.TabIndex = 14;
            // 
            // Mhd
            // 
            Mhd.Location = new Point(208, 114);
            Mhd.Name = "Mhd";
            Mhd.Size = new Size(271, 27);
            Mhd.TabIndex = 13;
            Mhd.TextChanged += MaNV_TextChanged;
            // 
            // Ngayban
            // 
            Ngayban.AutoSize = true;
            Ngayban.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Ngayban.Location = new Point(85, 164);
            Ngayban.Name = "Ngayban";
            Ngayban.Size = new Size(73, 18);
            Ngayban.TabIndex = 12;
            Ngayban.Text = "Ngày bán";
            // 
            // MaKH
            // 
            MaKH.AutoSize = true;
            MaKH.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            MaKH.Location = new Point(574, 119);
            MaKH.Name = "MaKH";
            MaKH.Size = new Size(117, 18);
            MaKH.TabIndex = 11;
            MaKH.Text = "Mã Khách hàng";
            // 
            // MaNhanVien
            // 
            MaNhanVien.AutoSize = true;
            MaNhanVien.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            MaNhanVien.Location = new Point(85, 208);
            MaNhanVien.Name = "MaNhanVien";
            MaNhanVien.Size = new Size(103, 18);
            MaNhanVien.TabIndex = 10;
            MaNhanVien.Text = "Mã nhân viên";
            // 
            // MaHD
            // 
            MaHD.AutoSize = true;
            MaHD.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point, 163);
            MaHD.Location = new Point(85, 118);
            MaHD.Name = "MaHD";
            MaHD.Size = new Size(96, 18);
            MaHD.TabIndex = 9;
            MaHD.Text = "Mã Hóa Đơn";
            // 
            // dataGridViewTKHD
            // 
            dataGridViewTKHD.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTKHD.Dock = DockStyle.Fill;
            dataGridViewTKHD.Location = new Point(0, 256);
            dataGridViewTKHD.Name = "dataGridViewTKHD";
            dataGridViewTKHD.RowHeadersWidth = 51;
            dataGridViewTKHD.Size = new Size(1437, 308);
            dataGridViewTKHD.TabIndex = 4;
            //dataGridViewTKHD.CellContentClick += dataGridViewTKHD_CellContentClick;
            // 
            // TimKiemHoaDon
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1437, 666);
            Controls.Add(dataGridViewTKHD);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "TimKiemHoaDon";
            Text = "TimKiemHoaDon";
            Load += TimKiemHoaDon_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTKHD).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button Đóng;
        private Button Timlai;
        private Button Timkiem;
        private Panel panel2;
        private Panel panel3;
        private DataGridView dataGridViewTKHD;
        private Label label1;
        private TextBox Nb;
        private TextBox Mkh;
        private TextBox Mnv;
        private TextBox Mhd;
        private Label Ngayban;
        private Label MaKH;
        private Label MaNhanVien;
        private Label MaHD;
        private TextBox Tgb;
        private Label Thoigianban;
        private TextBox Ttb;
        private Label Tongtienban;
        private Label dmTimkiemhoadon;
    }
}